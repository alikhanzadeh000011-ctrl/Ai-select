package com.aiselect.app

import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore

/** Measurements were taken from 1080px-wide reference screenshots; this scales them to any screen. */
fun Context.u(px: Float): Float = px * resources.displayMetrics.widthPixels / 1080f

fun Context.ui(px: Float): Int = u(px).toInt()

/** Saves bytes to Pictures/AI Select through MediaStore (no permission needed). */
fun saveToPictures(ctx: Context, name: String, mime: String, bytes: ByteArray): Boolean {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, name)
        put(MediaStore.Images.Media.MIME_TYPE, mime)
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI Select")
        put(MediaStore.Images.Media.IS_PENDING, 1)
    }
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
    ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
    values.clear()
    values.put(MediaStore.Images.Media.IS_PENDING, 0)
    ctx.contentResolver.update(uri, values, null, null)
    return true
}
