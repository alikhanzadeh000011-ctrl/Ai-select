package com.aiselect.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.max

/**
 * "Create GIF": shows the region frame and a Record pill over the live screen, grabs about
 * 3 frames per second (Android limits screenshots to one per ~330ms) and encodes a GIF.
 */
class GifRecorder(private val svc: AISelectService, private val region: Rect) {

    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val frames = ArrayList<ByteArray>()
    private var fw = 0
    private var fh = 0
    private var frameView: View? = null
    private var pill: LinearLayout? = null
    private var label: TextView? = null
    private var quality: TextView? = null
    private var recording = false
    private var high = true
    private var startMs = 0L
    private var lastShot = 0L

    private fun u(px: Float) = svc.u(px)

    private fun params(w: Int, h: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        return lp
    }

    fun show() {
        // frame drawn just outside the recorded region so it never ends up in the GIF
        val b = svc.ui(8f)
        val fv = object : View(svc) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                color = 0xFFFFFFFF.toInt()
                strokeWidth = b / 2f
            }
            val d = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                color = 0x66000000
                strokeWidth = b / 2f
            }

            override fun onDraw(c: Canvas) {
                val o = b / 4f
                c.drawRect(o, o, width - o, height - o, d)
                c.drawRect(o + b / 2f, o + b / 2f, width - o - b / 2f, height - o - b / 2f, p)
            }
        }
        val flp = params(region.width() + 2 * b, region.height() + 2 * b, false)
        flp.x = region.left - b
        flp.y = region.top - b
        wm.addView(fv, flp)
        frameView = fv

        // control pill (image 5 of the reference: dot + Record | quality | close)
        val pl = LinearLayout(svc)
        pl.orientation = LinearLayout.HORIZONTAL
        pl.gravity = Gravity.CENTER_VERTICAL
        pl.setPadding(svc.ui(44f), svc.ui(14f), svc.ui(14f), svc.ui(14f))
        pl.background = GradientDrawable().apply {
            setColor(0xF2232328.toInt())
            cornerRadius = u(70f)
        }
        val dot = View(svc)
        dot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xFFFF0000.toInt())
        }
        pl.addView(dot, LinearLayout.LayoutParams(svc.ui(40f), svc.ui(40f)))
        val rec = text("Record", true)
        label = rec
        val rl = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        rl.marginStart = svc.ui(24f)
        pl.addView(rec, rl)
        val div = View(svc)
        div.setBackgroundColor(0x44FFFFFF)
        val dl = LinearLayout.LayoutParams(svc.ui(2f), svc.ui(44f))
        dl.marginStart = svc.ui(30f)
        dl.marginEnd = svc.ui(30f)
        pl.addView(div, dl)
        val q = text("High quality \u25BE", false)
        quality = q
        pl.addView(q)
        val closeBtn = CloseButton(svc, 0xFF3A3A40.toInt())
        val cl = LinearLayout.LayoutParams(svc.ui(88f), svc.ui(88f))
        cl.marginStart = svc.ui(24f)
        pl.addView(closeBtn, cl)

        rec.setOnClickListener {
            if (!recording) startRecording() else stopRecording()
        }
        dot.setOnClickListener { rec.performClick() }
        q.setOnClickListener {
            if (!recording) {
                high = !high
                q.text = if (high) "High quality \u25BE" else "Standard quality \u25BE"
            }
        }
        closeBtn.setOnClickListener { dismiss() }

        val plp = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, true)
        val screenW = svc.resources.displayMetrics.widthPixels
        val screenH = svc.resources.displayMetrics.heightPixels
        plp.x = max(svc.ui(30f), (region.centerX() - svc.ui(380f)))
        plp.y = minOf(region.bottom + svc.ui(60f), screenH - svc.ui(260f))
        if (plp.x + svc.ui(760f) > screenW) plp.x = max(0, screenW - svc.ui(780f))
        wm.addView(pl, plp)
        pill = pl
    }

    private fun text(s: String, bold: Boolean): TextView {
        val t = TextView(svc)
        t.text = s
        t.setTextColor(0xFFFFFFFF.toInt())
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(38f))
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun startRecording() {
        recording = true
        startMs = SystemClock.uptimeMillis()
        label?.text = "Stop  0:00"
        quality?.alpha = 0.4f
        scheduleShot()
    }

    private fun scheduleShot() {
        if (!recording) return
        val wait = max(0L, 340L - (SystemClock.uptimeMillis() - lastShot))
        handler.postDelayed({ shoot() }, wait)
    }

    private fun shoot() {
        if (!recording) return
        lastShot = SystemClock.uptimeMillis()
        svc.takeShot { bmp ->
            if (bmp != null) worker.execute { addFrame(bmp) }
            val sec = ((SystemClock.uptimeMillis() - startMs) / 1000).toInt()
            label?.text = "Stop  ${sec / 60}:${(sec % 60).toString().padStart(2, '0')}"
            if (sec >= 20) stopRecording() else scheduleShot()
        }
    }

    private fun addFrame(full: Bitmap) {
        try {
            val l = region.left.coerceIn(0, full.width - 1)
            val t = region.top.coerceIn(0, full.height - 1)
            val w = region.width().coerceIn(1, full.width - l)
            val h = region.height().coerceIn(1, full.height - t)
            val crop = Bitmap.createBitmap(full, l, t, w, h)
            if (fw == 0) {
                val maxDim = if (high) 720f else 480f
                val s = minOf(1f, maxDim / max(w, h))
                fw = max(2, (w * s).toInt() and 1.inv())
                fh = max(2, (h * s).toInt() and 1.inv())
            }
            val scaled = Bitmap.createScaledBitmap(crop, fw, fh, true)
            val px = IntArray(fw * fh)
            scaled.getPixels(px, 0, fw, 0, 0, fw, fh)
            frames.add(GifEncoder.quantize(px, fw, fh))
            if (scaled !== crop) scaled.recycle()
            crop.recycle()
            full.recycle()
        } catch (e: Exception) {
        }
    }

    private fun stopRecording() {
        recording = false
        removeViews()
        Toast.makeText(svc, "Creating GIF\u2026", Toast.LENGTH_SHORT).show()
        worker.execute {
            val ok = if (frames.isEmpty()) {
                false
            } else {
                val bytes = GifEncoder.encode(frames, fw, fh, 33)
                saveToPictures(svc, "AISelect_${System.currentTimeMillis()}.gif", "image/gif", bytes)
            }
            handler.post {
                Toast.makeText(svc, if (ok) "GIF saved to Pictures/AI Select" else "Couldn't create GIF", Toast.LENGTH_LONG).show()
                svc.gifFinished()
            }
            worker.shutdown()
        }
    }

    private fun removeViews() {
        try {
            frameView?.let { wm.removeView(it) }
        } catch (e: Exception) {
        }
        try {
            pill?.let { wm.removeView(it) }
        } catch (e: Exception) {
        }
        frameView = null
        pill = null
    }

    fun dismiss() {
        recording = false
        removeViews()
        worker.shutdown()
        svc.gifFinished()
    }
}
