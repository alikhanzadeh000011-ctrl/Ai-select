package com.aiselect.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.WallpaperManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.window.OnBackInvokedDispatcher
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

class SelectActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var bgImg: ImageView
    private lateinit var rim: RimView
    private lateinit var glow: GlowView
    private lateinit var sparkles: LottieAnimationView
    private lateinit var selection: SelectionView
    private lateinit var chips: LinearLayout
    private lateinit var toolbar: LinearLayout
    private lateinit var textIcon: ImageView
    private lateinit var lottie: LottieAnimationView
    private lateinit var wallChip: LinearLayout
    private lateinit var moreBtn: FrameLayout
    private lateinit var close: CloseButton
    private lateinit var dotsTop: DotsView
    private var rimSpin: ValueAnimator? = null
    private var resultPanel: View? = null
    private var shot: Bitmap? = null
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bmp = ShotHolder.bitmap
        if (bmp == null) {
            finish()
            return
        }
        shot = bmp

        WindowCompat.setDecorFitsSystemWindows(window, false)
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        window.attributes = lp
        val ctrl = WindowInsetsControllerCompat(window, window.decorView)
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        bgImg = ImageView(this)
        bgImg.setImageBitmap(bmp)
        bgImg.scaleType = ImageView.ScaleType.FIT_XY
        root.addView(bgImg, FrameLayout.LayoutParams(match, match))

        rim = RimView(this)
        root.addView(rim, FrameLayout.LayoutParams(match, match))

        glow = GlowView(this)
        root.addView(glow, FrameLayout.LayoutParams(match, match))

        // the white Galaxy AI sparkles from the original Lottie
        sparkles = LottieAnimationView(this)
        sparkles.setAnimation(R.raw.intelligence_affordance)
        sparkles.visibility = View.INVISIBLE
        val sp = ui(155f)
        val spl = FrameLayout.LayoutParams(sp, sp, Gravity.TOP or Gravity.START)
        root.addView(sparkles, spl)

        selection = SelectionView(this)
        root.addView(selection, FrameLayout.LayoutParams(match, match))

        buildChips()
        buildToolbar()
        chips.visibility = View.GONE
        toolbar.visibility = View.GONE
        root.addView(chips, FrameLayout.LayoutParams(wrap, ui(96f), Gravity.TOP or Gravity.START))
        root.addView(toolbar, FrameLayout.LayoutParams(wrap, ui(132f), Gravity.TOP or Gravity.START))

        close = CloseButton(this)
        close.alpha = 0f
        close.setOnClickListener { finish() }
        val cl = FrameLayout.LayoutParams(ui(100f), ui(100f), Gravity.TOP or Gravity.END)
        cl.topMargin = ui(140f)
        cl.marginEnd = ui(110f)
        root.addView(close, cl)

        dotsTop = DotsView(this)
        dotsTop.alpha = 0f
        dotsTop.visibility = View.GONE
        dotsTop.setOnClickListener { showMenu(dotsTop) }
        val dl = FrameLayout.LayoutParams(ui(100f), ui(100f), Gravity.TOP or Gravity.END)
        dl.topMargin = ui(135f)
        dl.marginEnd = ui(80f)
        root.addView(dotsTop, dl)

        selection.onTouchStart = { onTouchStart() }
        selection.onSelected = { r -> onSelected(r) }
        selection.onCleared = { hidePanels() }

        setContentView(root)

        onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT) {
            handleBack()
        }

        playEntry()
    }

    private fun u(px: Float) = (this as android.content.Context).u(px)
    private fun ui(px: Float) = (this as android.content.Context).ui(px)

    // ---------- entry animation ----------

    private fun playEntry() {
        // sharp screen (no blur): a pastel wash spreads over it, then settles to a light colored tint
        selection.showIdleDim()
        close.animate().alpha(1f).setStartDelay(250).setDuration(300).start()

        val wash = ObjectAnimator.ofFloat(rim, "washAlpha", 0f, 0.55f, 0f)
        wash.duration = 1300
        wash.start()
        val tint = ObjectAnimator.ofFloat(rim, "tintAlpha", 0f, 1f)
        tint.duration = 900
        tint.startDelay = 300
        tint.start()
        val phase = ObjectAnimator.ofFloat(rim, "washPhase", 0f, 0.35f)
        phase.duration = 1700
        phase.start()
        val rimIn = ObjectAnimator.ofFloat(rim, "rimAlpha", 0f, 1f)
        rimIn.duration = 500
        rimIn.startDelay = 120
        rimIn.start()
        val spin = ValueAnimator.ofFloat(0f, 360f)
        spin.duration = 14000
        spin.repeatCount = ValueAnimator.INFINITE
        spin.interpolator = android.view.animation.LinearInterpolator()
        spin.addUpdateListener { rim.rimPhase = it.animatedValue as Float }
        rimSpin = spin
        spin.start()

        val sp = ui(155f)
        sparkles.translationX = root.resources.displayMetrics.widthPixels * 0.5f - sp / 2f
        sparkles.translationY = root.resources.displayMetrics.heightPixels * 0.5f - sp / 2f
        sparkles.postDelayed({
            sparkles.visibility = View.VISIBLE
            sparkles.playAnimation()
        }, 160)
        sparkles.addAnimatorListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                sparkles.visibility = View.INVISIBLE
            }
        })
    }

    private fun onTouchStart() {
        rimSpin?.cancel()
        ObjectAnimator.ofFloat(rim, "tintAlpha", rim.tintAlpha, 0f).setDuration(200).start()
        ObjectAnimator.ofFloat(rim, "rimAlpha", rim.rimAlpha, 0f).setDuration(220).start()
        ObjectAnimator.ofFloat(rim, "washAlpha", rim.washAlpha, 0f).setDuration(150).start()
        sparkles.visibility = View.INVISIBLE
        hidePanels()
    }

    private fun hidePanels() {
        for (v in listOf<View>(chips, toolbar)) {
            if (v.visibility == View.VISIBLE) {
                v.animate().cancel()
                v.animate().alpha(0f).setDuration(120).withEndAction { v.visibility = View.GONE }.start()
            }
        }
        if (dotsTop.visibility == View.VISIBLE) {
            dotsTop.animate().alpha(0f).setDuration(120).withEndAction { dotsTop.visibility = View.GONE }.start()
            close.animate().alpha(1f).setStartDelay(0).setDuration(150).start()
        }
    }

    // ---------- UI ----------

    private fun roundBg(color: Int, radius: Float, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = radius
        if (strokePx > 0) g.setStroke(strokePx, strokeColor)
        return g
    }

    private fun circleBtn(): FrameLayout {
        val f = FrameLayout(this)
        f.background = roundBg(0xE63B3F58.toInt(), u(60f), 0xFF565C7A.toInt(), ui(3f))
        f.elevation = u(6f)
        return f
    }

    private fun buildChips() {
        chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.gravity = Gravity.CENTER_VERTICAL

        // Extract text: round button on the left
        val ex = circleBtn()
        textIcon = ImageView(this)
        textIcon.setImageResource(R.drawable.ic_text)
        textIcon.imageTintList = ColorStateList.valueOf(0xFFFFFFFF.toInt())
        ex.addView(textIcon, FrameLayout.LayoutParams(ui(62f), ui(62f), Gravity.CENTER))
        lottie = LottieAnimationView(this)
        lottie.setAnimation(R.raw.intelligence_progress_color)
        lottie.repeatCount = LottieDrawable.INFINITE
        lottie.visibility = View.INVISIBLE
        ex.addView(lottie, FrameLayout.LayoutParams(ui(70f), ui(70f), Gravity.CENTER))
        ex.setOnClickListener { extractText() }
        chips.addView(ex, LinearLayout.LayoutParams(ui(96f), ui(96f)))

        chips.addView(View(this), LinearLayout.LayoutParams(ui(33f), 1))
        wallChip = chip(R.drawable.ic_wallpaper, "Set as wallpaper") { chooseWallpaper() }
        chips.addView(wallChip)
        chips.addView(View(this), LinearLayout.LayoutParams(ui(33f), 1))
        chips.addView(chip(R.drawable.ic_gif, "Create GIF") { createGif() })
        chips.addView(View(this), LinearLayout.LayoutParams(ui(33f), 1))

        // more (three dots) on the right
        moreBtn = circleBtn()
        val dots = DotsView(this)
        moreBtn.addView(dots, FrameLayout.LayoutParams(ui(96f), ui(96f)))
        moreBtn.setOnClickListener { showMenu(moreBtn) }
        chips.addView(moreBtn, LinearLayout.LayoutParams(ui(96f), ui(96f)))
    }

    private fun chip(icon: Int, label: String, onClick: () -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER_VERTICAL
        c.setPadding(ui(40f), 0, ui(46f), 0)
        c.background = roundBg(0xE63B3F58.toInt(), u(60f), 0xFF565C7A.toInt(), ui(3f))
        c.elevation = u(6f)
        val iv = ImageView(this)
        iv.setImageResource(icon)
        iv.imageTintList = ColorStateList.valueOf(0xFFFFFFFF.toInt())
        c.addView(iv, LinearLayout.LayoutParams(ui(58f), ui(58f)))
        val t = TextView(this)
        t.text = label
        t.setTextColor(0xFFFFFFFF.toInt())
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(37f))
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        val tl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tl.marginStart = ui(18f)
        c.addView(t, tl)
        c.setOnClickListener { onClick() }
        c.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ui(96f))
        return c
    }

    private fun buildToolbar() {
        toolbar = LinearLayout(this)
        toolbar.orientation = LinearLayout.HORIZONTAL
        toolbar.gravity = Gravity.CENTER_VERTICAL
        toolbar.setPadding(ui(22f), ui(18f), ui(22f), ui(18f))
        toolbar.elevation = u(8f)
        toolbar.background = roundBg(0xD02B2F33.toInt(), u(70f))
        val icons = listOf(R.drawable.ic_edit, R.drawable.ic_pin, R.drawable.ic_copy, R.drawable.ic_share, R.drawable.ic_save)
        val acts = listOf<() -> Unit>({ doEdit() }, { doPin() }, { doCopy() }, { doShare() }, { doSave() })
        for (i in icons.indices) {
            val b = ImageView(this)
            b.setImageResource(icons[i])
            b.imageTintList = ColorStateList.valueOf(0xFFFFFFFF.toInt())
            b.scaleType = ImageView.ScaleType.FIT_CENTER
            b.setPadding(ui(12f), ui(12f), ui(12f), ui(12f))
            b.background = roundBg(0xE61F2124.toInt(), u(60f))
            b.setOnClickListener { acts[i]() }
            val bl = LinearLayout.LayoutParams(ui(96f), ui(96f))
            if (i > 0) bl.marginStart = ui(49f)
            toolbar.addView(b, bl)
        }
    }

    private fun showMenu(anchor: View) {
        val pm = android.widget.PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Accessibility settings")
        pm.menu.add(0, 2, 1, "App info")
        pm.menu.add(0, 3, 2, "Close")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
                2 -> startActivity(
                    Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
                else -> finish()
            }
            true
        }
        pm.show()
    }

    private fun onSelected(r: RectF) {
        val w = root.width.toFloat()
        val h = root.height.toFloat()
        val chipH = u(96f)
        val tbW = measuredWidth(toolbar)
        val tbH = u(132f)

        // chip row: shrink "Set as wallpaper" and drop the dots when the row is too wide (as in the original)
        val maxW = w - u(140f)
        moreBtn.visibility = View.VISIBLE
        wallChip.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ui(96f))
        var chipW = measuredWidth(chips)
        if (chipW > maxW) {
            moreBtn.visibility = View.GONE
            wallChip.layoutParams = LinearLayout.LayoutParams(0, ui(96f), 1f)
            val lp = chips.layoutParams
            lp.width = maxW.toInt()
            chips.layoutParams = lp
            chipW = maxW
        } else {
            val lp = chips.layoutParams
            lp.width = ViewGroup.LayoutParams.WRAP_CONTENT
            chips.layoutParams = lp
        }

        val chipsAbove = r.top - u(38f) - chipH >= u(120f)
        val chipTop = if (chipsAbove) r.top - u(38f) - chipH else minOf(r.bottom + u(38f), h - u(420f))
        var tbTop = if (chipsAbove) r.bottom + u(60f) else chipTop + chipH + u(65f)
        tbTop = minOf(tbTop, h - u(110f) - tbH)

        place(chips, (r.centerX() - chipW / 2f).coerceIn(u(24f), maxOf(u(24f), w - chipW - u(24f))), chipTop)
        place(toolbar, ((w - tbW) / 2f), tbTop)

        // the X turns into the three dots once something is selected
        close.animate().alpha(0f).setDuration(150).start()
        dotsTop.visibility = View.VISIBLE
        dotsTop.animate().alpha(1f).setDuration(200).start()

        for (v in listOf<View>(chips, toolbar)) {
            v.animate().cancel()
            v.visibility = View.VISIBLE
            v.alpha = 0f
            v.animate().alpha(1f).setDuration(180).setStartDelay(60).start()
            val sa = SpringAnimation(v, DynamicAnimation.TRANSLATION_Y, v.translationY)
            sa.setStartValue(v.translationY + u(26f))
            sa.spring.setStiffness(SpringForce.STIFFNESS_MEDIUM)
            sa.spring.setDampingRatio(SpringForce.DAMPING_RATIO_LOW_BOUNCY)
            sa.start()
        }
    }

    private fun measuredWidth(v: View): Float {
        v.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        return v.measuredWidth.toFloat()
    }

    private fun place(v: View, x: Float, y: Float) {
        v.translationX = x
        v.translationY = y
    }

    // ---------- actions ----------

    private fun currentCrop(): Bitmap? {
        val s = shot ?: return null
        return selection.crop(s)
    }

    private fun cacheUri(bmp: Bitmap): Uri {
        val dir = File(cacheDir, "shared")
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }
        val f = File(dir, "aiselect_${System.currentTimeMillis()}.png")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return FileProvider.getUriForFile(this, "$packageName.files", f)
    }

    private fun doEdit() {
        val bmp = currentCrop() ?: return
        val uri = cacheUri(bmp)
        val i = Intent(Intent.ACTION_EDIT)
        i.setDataAndType(uri, "image/png")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "No editor found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun doPin() {
        val bmp = currentCrop() ?: return
        val r = selection.selectedRect()
        val svc = AISelectService.instance
        if (svc != null) {
            val sx = shot!!.width / root.width.toFloat()
            val sy = shot!!.height / root.height.toFloat()
            svc.pin(bmp, (r.left * sx).toInt(), (r.top * sy).toInt())
        }
        finish()
    }

    private fun doCopy() {
        val bmp = currentCrop() ?: return
        val uri = cacheUri(bmp)
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newUri(contentResolver, "AI Select", uri))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun doSave() {
        val bmp = currentCrop() ?: return
        val o = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, o)
        val ok = saveToPictures(this, "AISelect_${System.currentTimeMillis()}.png", "image/png", o.toByteArray())
        Toast.makeText(this, if (ok) "Saved to Pictures/AI Select" else "Couldn't save", Toast.LENGTH_SHORT).show()
        if (ok) finish()
    }

    private fun doShare() {
        val bmp = currentCrop() ?: return
        val uri = cacheUri(bmp)
        val i = Intent(Intent.ACTION_SEND)
        i.type = "image/png"
        i.putExtra(Intent.EXTRA_STREAM, uri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, null))
    }

    private fun chooseWallpaper() {
        val bmp = currentCrop() ?: return
        val names = arrayOf("Home screen", "Lock screen", "Home and lock screens")
        val flags = intArrayOf(WallpaperManager.FLAG_SYSTEM, WallpaperManager.FLAG_LOCK, WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
        android.app.AlertDialog.Builder(this)
            .setTitle("Set as wallpaper")
            .setItems(names) { _, which ->
                Thread {
                    try {
                        WallpaperManager.getInstance(this).setBitmap(bmp, null, true, flags[which])
                        runOnUiThread {
                            Toast.makeText(this, "Wallpaper set", Toast.LENGTH_SHORT).show()
                            finish()
                        }
                    } catch (e: Exception) {
                        runOnUiThread { Toast.makeText(this, "Couldn't set wallpaper", Toast.LENGTH_SHORT).show() }
                    }
                }.start()
            }
            .show()
    }

    private fun createGif() {
        val r = selection.selectedRect()
        val sx = shot!!.width / root.width.toFloat()
        val sy = shot!!.height / root.height.toFloat()
        val region = Rect((r.left * sx).toInt(), (r.top * sy).toInt(), (r.right * sx).toInt(), (r.bottom * sy).toInt())
        AISelectService.instance?.startGif(region)
        finish()
    }

    private fun extractText() {
        if (busy) return
        val crop = currentCrop() ?: return
        busy = true
        textIcon.visibility = View.INVISIBLE
        lottie.visibility = View.VISIBLE
        lottie.playAnimation()
        glow.start()
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        rec.process(InputImage.fromBitmap(crop, 0))
            .addOnSuccessListener { r ->
                endOcr()
                showResult(r.text.trim())
            }
            .addOnFailureListener {
                endOcr()
                showResult("")
            }
    }

    private fun endOcr() {
        busy = false
        lottie.cancelAnimation()
        lottie.visibility = View.INVISIBLE
        textIcon.visibility = View.VISIBLE
        glow.stop()
    }

    private fun showResult(text: String) {
        hideResult()
        val empty = text.isEmpty()
        val panel = FrameLayout(this)
        panel.setBackgroundColor(0x33000000)
        panel.setOnClickListener { hideResult() }

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(ui(64f), ui(64f), ui(64f), ui(40f))
        card.elevation = u(20f)
        card.isClickable = true
        card.background = roundBg(0xFFFCFCFC.toInt(), u(70f))

        val title = TextView(this)
        title.text = "Text"
        title.setTextColor(0xFF010101.toInt())
        title.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(44f))
        title.typeface = Typeface.DEFAULT_BOLD
        card.addView(title)

        val body = TextView(this)
        body.text = if (empty) "No text found in the selection" else text
        body.setTextColor(if (empty) 0xFF848487.toInt() else 0xFF505050.toInt())
        body.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(38f))
        body.setLineSpacing(u(10f), 1f)
        body.setTextIsSelectable(!empty)
        val scroll = ScrollView(this)
        scroll.addView(body)
        val sl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        sl.topMargin = ui(40f)
        sl.bottomMargin = ui(28f)
        card.addView(scroll, sl)
        body.viewTreeObserver.addOnGlobalLayoutListener {
            val maxH = ui(560f)
            if (scroll.height > maxH) {
                val p = scroll.layoutParams
                p.height = maxH
                scroll.layoutParams = p
            }
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.END
        if (!empty) {
            row.addView(textButton("Copy") {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("AI Select", text))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            })
            row.addView(textButton("Share") {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "text/plain"
                i.putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(i, null))
            })
        }
        row.addView(textButton("Close") { hideResult() })
        card.addView(row)

        val cl = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        cl.marginStart = ui(32f)
        cl.marginEnd = ui(32f)
        cl.bottomMargin = ui(60f)
        panel.addView(card, cl)

        root.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        resultPanel = panel
        card.translationY = ui(1200f).toFloat()
        val sa = SpringAnimation(card, DynamicAnimation.TRANSLATION_Y, 0f)
        sa.spring.setStiffness(SpringForce.STIFFNESS_LOW)
        sa.spring.setDampingRatio(SpringForce.DAMPING_RATIO_LOW_BOUNCY)
        sa.start()
    }

    private fun textButton(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(0xFF010101.toInt())
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(42f))
        t.setPadding(ui(36f), ui(22f), ui(36f), ui(22f))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun hideResult() {
        resultPanel?.let { root.removeView(it) }
        resultPanel = null
    }

    private fun handleBack() {
        if (resultPanel != null) hideResult() else finish()
    }

    override fun onDestroy() {
        rimSpin?.cancel()
        if (isFinishing) ShotHolder.bitmap = null
        super.onDestroy()
    }
}
