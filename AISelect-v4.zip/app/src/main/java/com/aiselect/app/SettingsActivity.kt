package com.aiselect.app

import android.app.Activity
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** The only screen of this app: setup and (later) settings. The AI Select action is a separate app. */
class SettingsActivity : Activity() {

    private lateinit var status: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(24), dp(72), dp(24), dp(32))

        col.addView(label("AI Select Settings", 28f, 0xFFFCFCFF.toInt(), true))
        status = label("", 14f, 0xFF88E6E3.toInt(), false)
        status.setPadding(0, dp(6), 0, dp(24))
        col.addView(status)

        col.addView(section("Service"))
        col.addView(pill("Open Accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(note(
            "Installed apps > AI Select Settings > turn it on. If Android says \"Restricted setting\", " +
                "open App info, tap the \u22EE menu and choose \"Allow restricted settings\", then try again."
        ))
        col.addView(pill("Open App info") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        col.addView(section("Shortcuts"))
        col.addView(pill("Add Quick Settings tile") { addTile() })
        col.addView(note("The \"AI Select\" app (separate APK) starts a capture with one tap. Put it in the Edge panel or on the home screen."))

        col.addView(section("Test"))
        col.addView(pill("Capture now") {
            val s = AISelectService.instance
            if (s == null) {
                Toast.makeText(this, "Turn on the accessibility service first", Toast.LENGTH_LONG).show()
            } else {
                moveTaskToBack(true)
                s.captureDelayed(600)
            }
        })

        val sv = ScrollView(this)
        sv.setBackgroundColor(0xFF101216.toInt())
        sv.addView(col)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (AISelectService.instance != null) "Service is on" else "Service is off"
    }

    private fun addTile() {
        try {
            val sbm = getSystemService(StatusBarManager::class.java)
            sbm.requestAddTileService(
                ComponentName(this, AISelectTile::class.java),
                getString(R.string.tile_label),
                Icon.createWithResource(this, R.drawable.ic_tile),
                mainExecutor
            ) { _ -> }
        } catch (e: Exception) {
            Toast.makeText(this, "Add it from the Quick Settings edit screen", Toast.LENGTH_LONG).show()
        }
    }

    private fun section(text: String): TextView {
        val t = label(text, 13f, 0xFF848487.toInt(), false)
        t.setPadding(0, dp(24), 0, dp(4))
        return t
    }

    private fun note(text: String): TextView {
        val t = label(text, 12f, 0xFF848487.toInt(), false)
        t.setPadding(0, dp(6), 0, dp(8))
        return t
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(color)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun pill(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.gravity = Gravity.CENTER
        t.setTextColor(0xFF010102.toInt())
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        t.setPadding(dp(16), dp(14), dp(16), dp(14))
        t.background = GradientDrawable().apply {
            setColor(0xFFFCFCFF.toInt())
            cornerRadius = dp(24).toFloat()
        }
        t.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        t.layoutParams = lp
        return t
    }
}
