package com.aiselect.app

import java.io.ByteArrayOutputStream
import kotlin.math.roundToInt

/** Small GIF89a writer: fixed 6x7x6 palette with ordered dithering, looping. */
object GifEncoder {

    private val BAYER = intArrayOf(0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5)

    fun quantize(px: IntArray, w: Int, h: Int): ByteArray {
        val out = ByteArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val c = px[y * w + x]
                val t = BAYER[(y and 3) * 4 + (x and 3)] / 16f - 0.5f
                val ri = ((c shr 16 and 255) / 255f * 5f + t).roundToInt().coerceIn(0, 5)
                val gi = ((c shr 8 and 255) / 255f * 6f + t).roundToInt().coerceIn(0, 6)
                val bi = ((c and 255) / 255f * 5f + t).roundToInt().coerceIn(0, 5)
                out[y * w + x] = (ri * 42 + gi * 6 + bi).toByte()
            }
        }
        return out
    }

    fun encode(frames: List<ByteArray>, w: Int, h: Int, delayCs: Int): ByteArray {
        val o = ByteArrayOutputStream()
        o.write("GIF89a".toByteArray())
        writeShort(o, w)
        writeShort(o, h)
        o.write(0xF7)
        o.write(0)
        o.write(0)
        // palette
        for (i in 0 until 256) {
            if (i < 252) {
                val r = i / 42
                val g = (i / 6) % 7
                val b = i % 6
                o.write(r * 51)
                o.write((g * 255f / 6f).roundToInt())
                o.write(b * 51)
            } else {
                o.write(0)
                o.write(0)
                o.write(0)
            }
        }
        // loop forever
        o.write(0x21)
        o.write(0xFF)
        o.write(11)
        o.write("NETSCAPE2.0".toByteArray())
        o.write(3)
        o.write(1)
        writeShort(o, 0)
        o.write(0)

        for (f in frames) {
            o.write(0x21)
            o.write(0xF9)
            o.write(4)
            o.write(0x00)
            writeShort(o, delayCs)
            o.write(0)
            o.write(0)
            o.write(0x2C)
            writeShort(o, 0)
            writeShort(o, 0)
            writeShort(o, w)
            writeShort(o, h)
            o.write(0)
            o.write(8)
            val data = lzw(f)
            var p = 0
            while (p < data.size) {
                val n = minOf(255, data.size - p)
                o.write(n)
                o.write(data, p, n)
                p += n
            }
            o.write(0)
        }
        o.write(0x3B)
        return o.toByteArray()
    }

    private fun writeShort(o: ByteArrayOutputStream, v: Int) {
        o.write(v and 255)
        o.write((v shr 8) and 255)
    }

    private fun lzw(px: ByteArray): ByteArray {
        val data = ByteArrayOutputStream()
        var acc = 0
        var nb = 0
        var codeSize = 9
        var next = 258
        val dict = HashMap<Int, Int>()

        fun put(code: Int) {
            acc = acc or (code shl nb)
            nb += codeSize
            while (nb >= 8) {
                data.write(acc and 255)
                acc = acc ushr 8
                nb -= 8
            }
        }

        put(256)
        var prefix = px[0].toInt() and 255
        for (i in 1 until px.size) {
            val b = px[i].toInt() and 255
            val key = (prefix shl 8) or b
            val found = dict[key]
            if (found != null) {
                prefix = found
            } else {
                put(prefix)
                if (next >= (1 shl codeSize) && codeSize < 12) codeSize++
                if (next < 4096) {
                    dict[key] = next
                    next++
                } else {
                    put(256)
                    dict.clear()
                    codeSize = 9
                    next = 258
                }
                prefix = b
            }
        }
        put(prefix)
        if (next >= (1 shl codeSize) && codeSize < 12) codeSize++
        put(257)
        if (nb > 0) data.write(acc and 255)
        return data.toByteArray()
    }
}
