package com.aiselect.action

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/** The "AI Select" icon: no screen, it just fires the capture action of the settings app. */
class ActionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val i = Intent()
            i.setClassName("com.aiselect.app", "com.aiselect.app.CaptureActivity")
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Install \"AI Select Settings\" first", Toast.LENGTH_LONG).show()
        }
        finish()
    }
}
