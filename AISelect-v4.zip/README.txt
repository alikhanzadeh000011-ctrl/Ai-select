AI Select v4 - two APKs (Android 13+, tuned for Android 17 / One UI 9)

1) AI Select Settings (com.aiselect.app): the accessibility service, the selection screen and
   the settings screen. Its icon only opens settings. Install this first.
2) AI Select (com.aiselect.action): the action app. No screen; tapping its icon captures
   immediately. Put it in the Edge panel / home screen.

Setup: install both, then Settings > Accessibility > Installed apps > AI Select Settings > on
(if blocked: App info > menu > Allow restricted settings).

v4 visual fixes: no blur, color tint + thin pastel rim, white glassy stroke, no effect inside the
selected square, bigger toolbar/chip icons.
