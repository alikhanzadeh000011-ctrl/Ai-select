package com.aiselect.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/**
 * The two "entry" effects: a pastel color wash that spreads across the screen, and the
 * glowing rim around the screen edge (yellow-green on top, cyan, blue, lavender at the bottom).
 */
class RimView(context: Context) : View(context) {

    var rimAlpha: Float = 0f
        set(v) {
            field = v
            invalidate()
        }
    var washAlpha: Float = 0f
        set(v) {
            field = v
            invalidate()
        }
    var washPhase: Float = 0f
        set(v) {
            field = v
            invalidate()
        }

    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private val washPaint = Paint()
    private val path = Path()

    private val rimColors = intArrayOf(
        0xFFE4F58B.toInt(), 0xFFC8F7A8.toInt(), 0xFF8FE8E0.toInt(), 0xFF9DB5FF.toInt(), 0xFFBBA7FF.toInt()
    )
    private val rimPos = floatArrayOf(0f, 0.3f, 0.55f, 0.8f, 1f)
    private val washColors = intArrayOf(
        0xFFF4F4A0.toInt(), 0xFFA5E6D2.toInt(), 0xFF9DB4FF.toInt(), 0xFFC7A6FF.toInt()
    )

    init {
        visibility = VISIBLE
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        rimPaint.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), rimColors, rimPos, Shader.TileMode.CLAMP)
        path.reset()
        val inset = context.u(8f)
        val r = context.u(95f)
        path.addRoundRect(RectF(inset, inset, w - inset, h - inset), r, r, Path.Direction.CW)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (washAlpha > 0.001f) {
            val a = washPhase * 6.2831855f
            val d = h * 0.6f
            val cx = w / 2f
            val cy = h / 2f
            washPaint.shader = LinearGradient(
                cx - cos(a) * d * 0.5f, cy - sin(a) * d, cx + cos(a) * d * 0.5f, cy + sin(a) * d,
                washColors, null, Shader.TileMode.CLAMP
            )
            washPaint.alpha = (washAlpha.coerceIn(0f, 1f) * 255).toInt()
            c.drawRect(0f, 0f, w, h, washPaint)
        }
        if (rimAlpha > 0.001f) {
            val widths = floatArrayOf(56f, 36f, 22f, 14f)
            val alphas = floatArrayOf(0.12f, 0.22f, 0.45f, 1f)
            for (i in widths.indices) {
                rimPaint.strokeWidth = context.u(widths[i])
                rimPaint.alpha = (alphas[i] * rimAlpha.coerceIn(0f, 1f) * 255).toInt()
                c.drawPath(path, rimPaint)
            }
        }
    }
}
