package com.aiselect.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

/**
 * No screen: tapping the app icon (or the Quick Settings tile) captures right away.
 * Only if the accessibility service is off does it open the accessibility settings.
 */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val service = AISelectService.instance
        if (service == null) {
            Toast.makeText(this, "Turn on AI Select in Accessibility settings", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } else {
            service.captureDelayed(120)
        }
        finish()
    }
}
