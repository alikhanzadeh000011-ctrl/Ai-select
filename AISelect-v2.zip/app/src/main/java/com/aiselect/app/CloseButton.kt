package com.aiselect.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Round button with an X, as in AI Select's top-right corner. */
class CloseButton(context: Context, private val bgColor: Int = 0xE6505052.toInt()) : View(context) {

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bgColor }
    private val x = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = context.u(5f)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        c.drawCircle(cx, cy, width / 2f, bg)
        val k = width * 0.17f
        c.drawLine(cx - k, cy - k, cx + k, cy + k, x)
        c.drawLine(cx - k, cy + k, cx + k, cy - k, x)
    }
}
