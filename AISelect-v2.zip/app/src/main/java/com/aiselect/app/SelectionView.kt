package com.aiselect.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * AI Select selection layer: draw any stroke around something, it snaps into a glowing
 * rounded rectangle with four tinted corner brackets that can be moved and resized.
 */
class SelectionView(context: Context) : View(context) {

    enum class State { IDLE, DRAWING, SELECTED }

    var state: State = State.IDLE
        private set

    var onTouchStart: (() -> Unit)? = null
    var onSelected: ((RectF) -> Unit)? = null
    var onCleared: (() -> Unit)? = null

    private val rect = RectF()
    private val strokePath = Path()
    private var lastX = 0f
    private var lastY = 0f
    private var startX = 0f
    private var startY = 0f
    private var minX = 0f
    private var minY = 0f
    private var maxX = 0f
    private var maxY = 0f

    private enum class Drag { NONE, STROKE, MOVE, RESIZE }

    private var drag = Drag.NONE
    private var eL = false
    private var eR = false
    private var eT = false
    private var eB = false
    private var ax = 0f
    private var ay = 0f

    private var dimAlpha = 0f
    private var dimAnim: ValueAnimator? = null
    private var strokeAlpha = 0f
    private var selProgress = 1f
    private var spring: SpringAnimation? = null

    private class Dust(val x: Float, val y: Float, val vx: Float, val vy: Float, val born: Long, val life: Long, val size: Float, val color: Int)

    private val dust = ArrayList<Dust>()

    private val dimPaint = Paint().apply { color = 0xFF000000.toInt() }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = 0xFF081418.toInt()
    }
    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private val dustPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val bTl = BitmapFactory.decodeResource(resources, R.drawable.corner_tl)
    private val bTr = BitmapFactory.decodeResource(resources, R.drawable.corner_tr)
    private val bBl = BitmapFactory.decodeResource(resources, R.drawable.corner_bl)
    private val bBr = BitmapFactory.decodeResource(resources, R.drawable.corner_br)

    private fun tint(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    private val pTl = tint(0xFF88B6FE.toInt())
    private val pTr = tint(0xFF8EDEE6.toInt())
    private val pBl = tint(0xFF8BCDF0.toInt())
    private val pBr = tint(0xFF7EE1B1.toInt())

    private val sweepColors = intArrayOf(
        0xFFD7EFB0.toInt(), 0xFF7EE1B1.toInt(), 0xFFC5EFC8.toInt(), 0xFF8BCDF0.toInt(),
        0xFF86AEFF.toInt(), 0xFF7EA6FF.toInt(), 0xFFA8D0F8.toInt(), 0xFF8EDEE6.toInt(), 0xFFD7EFB0.toInt()
    )

    private fun u(px: Float) = context.u(px)

    private fun animateDim(to: Float) {
        dimAnim?.cancel()
        val a = ValueAnimator.ofFloat(dimAlpha, to)
        a.duration = 240
        a.addUpdateListener {
            dimAlpha = it.animatedValue as Float
            invalidate()
        }
        dimAnim = a
        a.start()
    }

    fun showIdleDim() {
        animateDim(0.30f)
    }

    fun clearSelection() {
        val had = state != State.IDLE
        state = State.IDLE
        drag = Drag.NONE
        strokePath.reset()
        strokeAlpha = 0f
        dust.clear()
        animateDim(0.30f)
        invalidate()
        if (had) onCleared?.invoke()
    }

    private fun roundRect(r: RectF): Path {
        val p = Path()
        p.addRoundRect(r, u(48f), u(48f), Path.Direction.CW)
        return p
    }

    private fun currentRect(): RectF {
        val k = 0.94f + 0.06f * selProgress.coerceIn(0f, 1.15f)
        val cx = rect.centerX()
        val cy = rect.centerY()
        val w = rect.width() * k
        val h = rect.height() * k
        return RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val now = SystemClock.uptimeMillis()

        // dim layer
        dimPaint.alpha = (dimAlpha.coerceIn(0f, 1f) * 255).toInt()
        if (state == State.SELECTED) {
            val rc = currentRect()
            c.save()
            c.clipOutPath(roundRect(rc))
            c.drawRect(0f, 0f, w, h, dimPaint)
            c.restore()
            drawSelection(c, rc)
        } else {
            c.drawRect(0f, 0f, w, h, dimPaint)
        }

        // stroke while drawing / fading
        if (strokeAlpha > 0.01f && !strokePath.isEmpty) {
            val ex = if (abs(lastX - startX) < 1f) startX + 1f else lastX
            glowPaint.shader = LinearGradient(startX, startY, ex, lastY, 0xFF86C6F2.toInt(), 0xFF7FE3A8.toInt(), Shader.TileMode.CLAMP)
            val ws = floatArrayOf(46f, 32f, 20f)
            val al = floatArrayOf(0.16f, 0.28f, 0.5f)
            for (i in ws.indices) {
                glowPaint.strokeWidth = u(ws[i])
                glowPaint.alpha = (al[i] * strokeAlpha * 255).toInt()
                c.drawPath(strokePath, glowPaint)
            }
            corePaint.strokeWidth = u(7f)
            corePaint.alpha = (0.88f * strokeAlpha * 255).toInt()
            c.drawPath(strokePath, corePaint)
        }

        // glowing dust
        if (dust.isNotEmpty()) {
            val iter = dust.iterator()
            while (iter.hasNext()) {
                val d = iter.next()
                val t = (now - d.born).toFloat() / d.life
                if (t >= 1f) {
                    iter.remove()
                    continue
                }
                dustPaint.color = d.color
                dustPaint.alpha = ((1f - t) * 0.85f * 255).toInt()
                c.drawCircle(d.x + d.vx * t, d.y + d.vy * t, d.size * (1f - 0.4f * t), dustPaint)
            }
            postInvalidateOnAnimation()
        }
    }

    private fun drawSelection(c: Canvas, rc: RectF) {
        val a = selProgress.coerceIn(0f, 1f)
        val p = roundRect(rc)
        outlinePaint.shader = SweepGradient(rc.centerX(), rc.centerY(), sweepColors, null)
        val ws = floatArrayOf(44f, 26f, 12f)
        val al = floatArrayOf(0.10f, 0.16f, 0.25f)
        for (i in ws.indices) {
            outlinePaint.strokeWidth = u(ws[i])
            outlinePaint.alpha = (al[i] * a * 255).toInt()
            c.drawPath(p, outlinePaint)
        }
        outlinePaint.strokeWidth = u(5f)
        outlinePaint.alpha = (a * 255).toInt()
        c.drawPath(p, outlinePaint)

        val s = u(86f)
        val off = u(4f)
        val ba = (a * 255).toInt()
        pTl.alpha = ba
        pTr.alpha = ba
        pBl.alpha = ba
        pBr.alpha = ba
        corner(c, bTl, pTl, rc.left - off, rc.top - off, 0f, 0f, s)
        corner(c, bTr, pTr, rc.right + off, rc.top - off, -s, 0f, s)
        corner(c, bBl, pBl, rc.left - off, rc.bottom + off, 0f, -s, s)
        corner(c, bBr, pBr, rc.right + off, rc.bottom + off, -s, -s, s)
    }

    private fun corner(c: Canvas, b: Bitmap, p: Paint, x: Float, y: Float, dx: Float, dy: Float, s: Float) {
        c.drawBitmap(b, null, RectF(x + dx, y + dy, x + dx + s, y + dy + s), p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x.coerceIn(0f, width.toFloat())
        val y = e.y.coerceIn(0f, height.toFloat())
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                onTouchStart?.invoke()
                if (state == State.SELECTED) {
                    val t = u(56f)
                    val inside = x >= rect.left - t && x <= rect.right + t && y >= rect.top - t && y <= rect.bottom + t
                    val dl = abs(x - rect.left)
                    val dr = abs(x - rect.right)
                    val dt = abs(y - rect.top)
                    val db = abs(y - rect.bottom)
                    eL = dl < t && dl <= dr
                    eR = dr < t && !eL
                    eT = dt < t && dt <= db
                    eB = db < t && !eT
                    if (inside && (eL || eR || eT || eB)) {
                        drag = Drag.RESIZE
                    } else if (rect.contains(x, y)) {
                        drag = Drag.MOVE
                        ax = x
                        ay = y
                    } else {
                        startStroke(x, y)
                    }
                } else {
                    startStroke(x, y)
                }
            }

            MotionEvent.ACTION_MOVE -> {
                when (drag) {
                    Drag.STROKE -> {
                        val mx = (lastX + x) / 2f
                        val my = (lastY + y) / 2f
                        strokePath.quadTo(lastX, lastY, mx, my)
                        lastX = x
                        lastY = y
                        minX = min(minX, x)
                        minY = min(minY, y)
                        maxX = max(maxX, x)
                        maxY = max(maxY, y)
                        spawnDust(x, y)
                    }
                    Drag.MOVE -> {
                        val w = rect.width()
                        val h = rect.height()
                        val l = (rect.left + (x - ax)).coerceIn(0f, max(0f, width - w))
                        val t = (rect.top + (y - ay)).coerceIn(0f, max(0f, height - h))
                        rect.set(l, t, l + w, t + h)
                        ax = x
                        ay = y
                    }
                    Drag.RESIZE -> {
                        val r = RectF(rect)
                        if (eL) r.left = x
                        if (eR) r.right = x
                        if (eT) r.top = y
                        if (eB) r.bottom = y
                        val mn = u(140f)
                        if (r.width() >= mn && r.height() >= mn) rect.set(r)
                    }
                    Drag.NONE -> {}
                }
                invalidate()
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                when (drag) {
                    Drag.STROKE -> finishStroke()
                    Drag.MOVE, Drag.RESIZE -> onSelected?.invoke(RectF(rect))
                    Drag.NONE -> {}
                }
                drag = Drag.NONE
                invalidate()
            }
        }
        return true
    }

    private fun startStroke(x: Float, y: Float) {
        val had = state == State.SELECTED
        state = State.DRAWING
        drag = Drag.STROKE
        strokePath.reset()
        strokePath.moveTo(x, y)
        lastX = x
        lastY = y
        startX = x
        startY = y
        minX = x
        maxX = x
        minY = y
        maxY = y
        strokeAlpha = 1f
        animateDim(0.35f)
        if (had) onCleared?.invoke()
    }

    private fun finishStroke() {
        val w = maxX - minX
        val h = maxY - minY
        if (w > u(110f) && h > u(110f)) {
            rect.set(minX, minY, maxX, maxY)
            rect.inset(-u(12f), -u(12f))
            rect.intersect(0f, 0f, width.toFloat(), height.toFloat())
            state = State.SELECTED
            animateDim(0.66f)
            // stroke fades, rectangle springs in
            val fade = ValueAnimator.ofFloat(1f, 0f)
            fade.duration = 220
            fade.addUpdateListener {
                strokeAlpha = it.animatedValue as Float
                invalidate()
            }
            fade.start()
            spring?.cancel()
            selProgress = 0f
            val sa = SpringAnimation(FloatValueHolder(0f))
            sa.setSpring(
                SpringForce(1f)
                    .setStiffness(SpringForce.STIFFNESS_MEDIUM)
                    .setDampingRatio(SpringForce.DAMPING_RATIO_LOW_BOUNCY)
            )
            sa.setStartValue(0f)
            sa.addUpdateListener { _, value, _ ->
                selProgress = value
                invalidate()
            }
            spring = sa
            sa.start()
            onSelected?.invoke(RectF(rect))
        } else {
            val fade = ValueAnimator.ofFloat(1f, 0f)
            fade.duration = 200
            fade.addUpdateListener {
                strokeAlpha = it.animatedValue as Float
                invalidate()
            }
            fade.start()
            state = State.IDLE
            animateDim(0.30f)
            onCleared?.invoke()
        }
    }

    private fun spawnDust(x: Float, y: Float) {
        val now = SystemClock.uptimeMillis()
        for (i in 0 until 3) {
            dust.add(
                Dust(
                    x + Random.nextFloat() * u(60f) - u(30f),
                    y + Random.nextFloat() * u(60f) - u(30f),
                    Random.nextFloat() * u(30f) - u(15f),
                    -Random.nextFloat() * u(40f),
                    now,
                    450L + Random.nextLong(450L),
                    u(1.2f) + Random.nextFloat() * u(2.2f),
                    if (Random.nextBoolean()) 0xFFFFFFFF.toInt() else 0xFFBFF3FF.toInt()
                )
            )
        }
        if (dust.size > 160) dust.subList(0, dust.size - 160).clear()
    }

    /** Cuts the selected rectangle out of the full-resolution screenshot. */
    fun crop(src: Bitmap): Bitmap? {
        if (state != State.SELECTED || width == 0 || height == 0) return null
        val sx = src.width / width.toFloat()
        val sy = src.height / height.toFloat()
        val l = (rect.left * sx).toInt().coerceIn(0, src.width - 1)
        val t = (rect.top * sy).toInt().coerceIn(0, src.height - 1)
        val r = (rect.right * sx).toInt().coerceIn(l + 1, src.width)
        val b = (rect.bottom * sy).toInt().coerceIn(t + 1, src.height)
        return Bitmap.createBitmap(src, l, t, r - l, b - t)
    }

    fun selectedRect(): RectF = RectF(rect)
}
