AI Select v2 (personal use) - Android 13+, tuned for Android 17 / One UI 9

v2 changes (based on your screen recordings):
- Tap the app icon (or the Quick Settings tile): captures immediately, no screen in between.
- Entry: blur + pastel color wash + glowing screen rim + the Galaxy AI sparkles (original Lottie).
- Draw any stroke: glowing stroke with light dust -> snaps to a rounded square with 4 tinted corner
  brackets; move/resize it. Dark dim outside.
- Chips: Set as wallpaper / Create GIF. Toolbar: Edit, Pin, Copy, Share, Save.
- Extract text capsule kept (Latin OCR only).

Setup: Settings > Accessibility > Installed apps > AI Select > on
(if blocked: App info > menu > Allow restricted settings).
Pin and Create GIF use accessibility overlays, so no extra permission is needed.
Create GIF records about 3 frames/second (Android's screenshot limit), up to 20 seconds.
