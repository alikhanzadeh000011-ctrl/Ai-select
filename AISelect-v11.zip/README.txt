AI Select v11 - two APKs (Android 13+, tuned for Android 17 / One UI 9)

1) AI Select Settings (com.aiselect.app): the accessibility service, the selection screen and
   the settings screen. Its icon only opens settings. Install this first.
2) AI Select (com.aiselect.action): the action app. No screen; tapping its icon captures
   immediately. Put it in the Edge panel / home screen.

Setup: install both, then Settings > Accessibility > Installed apps > AI Select Settings > on
(if blocked: App info > menu > Allow restricted settings).

v6 fixes: glass-tube stroke, thinner rim and lighter tint, toolbar and chips follow the square, original colors, text button only when text is found. Earlier v4 fixes: no blur, color tint + thin pastel rim, white glassy stroke, no effect inside the
selected square, bigger toolbar/chip icons.

v7: stroke is now the original dark see-through line with soft colored light around it; new Edge handle (Settings): hold a side handle to start AI Select, with vibration, position/length/thickness/side/color, invisible mode and the exact timing of the original recording.

v8: the color splash now spreads from the edge handle over the whole screen; invisible handle is still invisible until you hold it, then the colored bar shows and fades.

v9: see-through stroke (line cut out of the glow), colored edge handle has its own size sliders, toolbar/chip colors and idle tint sampled from the original, toolbar and chips hide while holding the square and animate back on release, top three dots removed.

v10: closing (back) cuts instantly like the original; action app and tile effect bursts from a blob near the screen center and covers the screen.

v11: AI Select screen uses a see-through window theme (no black frame when it opens, no shrink-to-icon when it closes).
