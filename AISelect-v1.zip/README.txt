AI Select v1 (personal use)
Android 13+ (built for Android 17 / One UI 9). Package: com.aiselect.app

Build: put the contents of this zip at the root of your GitHub repo (the workflow
.github/workflows/build.yml builds a debug APK -> Artifacts "AISelect-apk").

Setup on the phone:
1. Open AI Select > "Open Accessibility settings" > turn AI Select on.
   If it says "Restricted setting": App info > menu (3 dots) > Allow restricted settings.
2. "Add tile" (Quick Settings tile) and tap it from any screen.

Assets taken from Samsung Capture: Lottie progress star, AGSL glow shader, crop handle
bitmaps + 4 tint colors, shape icons, copy/save/share/text icons, colors and dp sizes.
