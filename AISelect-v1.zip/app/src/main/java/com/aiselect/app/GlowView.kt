package com.aiselect.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RuntimeShader
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * The rotating blue-green wash from AI Select, ported from the original AGSL shader
 * (gradient 94,161,253 -> 79,234,188 rotating with time, plus dithering noise).
 */
class GlowView(context: Context) : View(context) {

    private val rt = RuntimeShader(SRC)
    private val paint = Paint()
    private var timeSec = 0f
    private var anim: ValueAnimator? = null

    init {
        paint.shader = rt
        alpha = 0f
        visibility = GONE
    }

    override fun onDraw(canvas: Canvas) {
        rt.setFloatUniform("iResolution", width.toFloat(), height.toFloat())
        rt.setFloatUniform("iTime", timeSec)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }

    fun start() {
        visibility = VISIBLE
        if (anim?.isRunning != true) {
            anim = ValueAnimator.ofFloat(0f, 1000f).apply {
                duration = 1_000_000L
                interpolator = LinearInterpolator()
                addUpdateListener {
                    timeSec = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }
        animate().alpha(1f).setDuration(350).start()
    }

    fun stop() {
        animate().alpha(0f).setDuration(450).withEndAction {
            if (alpha == 0f) {
                anim?.cancel()
                anim = null
                visibility = GONE
            }
        }.start()
    }

    fun pulse(ms: Long) {
        start()
        postDelayed({ stop() }, ms)
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    companion object {
        private const val SRC = """
uniform float2 iResolution;
uniform float iTime;

float gnoise(float2 uv) {
    const float3 magic = float3(0.06711056, 0.00583715, 52.9829189);
    return fract(magic.z * fract(dot(uv, magic.xy)));
}

half4 main(float2 fc) {
    float2 uv = fc / iResolution;
    uv.x *= iResolution.x / iResolution.y;
    uv -= 0.5;
    float a = iTime * 2.0;
    float c = cos(a);
    float s = sin(a);
    float2 r = float2(uv.x * c - uv.y * s, uv.x * s + uv.y * c);
    float3 c1 = float3(94.0, 161.0, 253.0) / 255.0;
    float3 c2 = float3(79.0, 234.0, 188.0) / 255.0;
    float3 col = mix(c1, c2, smoothstep(-1.0, 1.0, r.x));
    float alpha = 0.22;
    float n = (1.0 / 255.0) * gnoise(fc) - (0.5 / 255.0);
    return half4(half3(col * alpha + n), half(alpha));
}
"""
    }
}
