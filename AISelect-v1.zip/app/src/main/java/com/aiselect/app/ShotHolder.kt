package com.aiselect.app

import android.graphics.Bitmap

/** Holds the last screenshot in memory (too big to pass through an Intent). */
object ShotHolder {
    @Volatile
    var bitmap: Bitmap? = null
}
