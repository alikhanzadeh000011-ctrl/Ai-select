package com.aiselect.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * Selection layer: rectangle, oval or freeform. Colors and sizes come from the original
 * Samsung Capture resources (dim gradient, outline colors, 27dp corner handles with
 * four different tints, 28dp touch margin, 52dp minimum size).
 */
class SelectionView(context: Context) : View(context) {

    enum class Mode { RECT, OVAL, LASSO }

    private enum class Drag { NONE, NEW, MOVE, RESIZE, LASSO }

    var mode: Mode = Mode.RECT
        set(value) {
            field = value
            clearSelection()
        }

    var onSelectionChanged: ((Boolean) -> Unit)? = null
    var onInteractionStart: (() -> Unit)? = null

    var hasSelection = false
        private set

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private val rect = RectF()
    private val lassoPath = Path()
    private val lassoPts = ArrayList<PointF>()
    private var drag = Drag.NONE
    private var drawing = false
    private var ax = 0f
    private var ay = 0f
    private var eL = false
    private var eR = false
    private var eT = false
    private var eB = false

    private var handleScale = 1f
    private var spring: SpringAnimation? = null

    private val dimPaint = Paint()
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(8f)
        alpha = 70
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    private val cornerTl = BitmapFactory.decodeResource(resources, R.drawable.corner_tl)
    private val cornerTr = BitmapFactory.decodeResource(resources, R.drawable.corner_tr)
    private val cornerBl = BitmapFactory.decodeResource(resources, R.drawable.corner_bl)
    private val cornerBr = BitmapFactory.decodeResource(resources, R.drawable.corner_br)

    private fun tintPaint(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    // ai_select_crop_handler_tint_color_* from the original app
    private val pTl = tintPaint(0xFF88B6FE.toInt())
    private val pTr = tintPaint(0xFF8EDEE6.toInt())
    private val pBl = tintPaint(0xFF8BCDF0.toInt())
    private val pBr = tintPaint(0xFF7EE1B1.toInt())

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        // ai_select_dim_background_top / bottom
        dimPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(), 0x4D000000, 0x33000000, Shader.TileMode.CLAMP
        )
        // ai_select_outline_renderer_color_with_opacity_1 / _3
        val g = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(), 0xFFACCCFF.toInt(), 0xFFDDFFCC.toInt(), Shader.TileMode.CLAMP
        )
        strokePaint.shader = g
        glowPaint.shader = g
    }

    fun selectionPath(): Path {
        val p = Path()
        when (mode) {
            Mode.RECT -> p.addRoundRect(rect, dp(6f), dp(6f), Path.Direction.CW)
            Mode.OVAL -> p.addOval(rect, Path.Direction.CW)
            Mode.LASSO -> p.addPath(lassoPath)
        }
        return p
    }

    fun selectionBounds(out: RectF) {
        selectionPath().computeBounds(out, true)
    }

    fun clearSelection() {
        val had = hasSelection
        hasSelection = false
        drawing = false
        drag = Drag.NONE
        rect.setEmpty()
        lassoPath.reset()
        lassoPts.clear()
        invalidate()
        if (had) onSelectionChanged?.invoke(false)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (hasSelection || drawing) {
            val p = selectionPath()
            c.save()
            c.clipOutPath(p)
            c.drawRect(0f, 0f, w, h, dimPaint)
            c.restore()
            c.drawPath(p, glowPaint)
            c.drawPath(p, strokePaint)
            if (hasSelection && mode != Mode.LASSO) drawCorners(c)
        } else {
            c.drawRect(0f, 0f, w, h, dimPaint)
        }
    }

    private fun drawCorners(c: Canvas) {
        val s = dp(27f)
        val off = dp(3.5f)
        corner(c, cornerTl, pTl, rect.left - off, rect.top - off, RectF(0f, 0f, s, s))
        corner(c, cornerTr, pTr, rect.right + off, rect.top - off, RectF(-s, 0f, 0f, s))
        corner(c, cornerBl, pBl, rect.left - off, rect.bottom + off, RectF(0f, -s, s, 0f))
        corner(c, cornerBr, pBr, rect.right + off, rect.bottom + off, RectF(-s, -s, 0f, 0f))
    }

    private fun corner(c: Canvas, bmp: Bitmap, paint: Paint, x: Float, y: Float, dst: RectF) {
        c.save()
        c.translate(x, y)
        c.scale(handleScale, handleScale)
        c.drawBitmap(bmp, null, dst, paint)
        c.restore()
    }

    private fun popHandles() {
        spring?.cancel()
        handleScale = 0.4f
        val sa = SpringAnimation(FloatValueHolder(0.4f))
        sa.setSpring(
            SpringForce(1f)
                .setStiffness(SpringForce.STIFFNESS_MEDIUM)
                .setDampingRatio(SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY)
        )
        sa.addUpdateListener { _, value, _ ->
            handleScale = value
            invalidate()
        }
        spring = sa
        sa.start()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x.coerceIn(0f, width.toFloat())
        val y = e.y.coerceIn(0f, height.toFloat())
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                onInteractionStart?.invoke()
                if (mode == Mode.LASSO) {
                    startLasso(x, y)
                } else if (hasSelection) {
                    val t = dp(28f)
                    val inside = x >= rect.left - t && x <= rect.right + t && y >= rect.top - t && y <= rect.bottom + t
                    val dl = abs(x - rect.left)
                    val dr = abs(x - rect.right)
                    val dt = abs(y - rect.top)
                    val db = abs(y - rect.bottom)
                    eL = dl < t && dl <= dr
                    eR = dr < t && !eL
                    eT = dt < t && dt <= db
                    eB = db < t && !eT
                    if (inside && (eL || eR || eT || eB)) {
                        drag = Drag.RESIZE
                    } else if (rect.contains(x, y)) {
                        drag = Drag.MOVE
                        ax = x
                        ay = y
                    } else {
                        startNew(x, y)
                    }
                } else {
                    startNew(x, y)
                }
            }

            MotionEvent.ACTION_MOVE -> {
                when (drag) {
                    Drag.NEW -> rect.set(min(ax, x), min(ay, y), max(ax, x), max(ay, y))
                    Drag.MOVE -> {
                        val w = rect.width()
                        val h = rect.height()
                        val l = (rect.left + (x - ax)).coerceIn(0f, max(0f, width - w))
                        val t = (rect.top + (y - ay)).coerceIn(0f, max(0f, height - h))
                        rect.set(l, t, l + w, t + h)
                        ax = x
                        ay = y
                    }
                    Drag.RESIZE -> {
                        val r = RectF(rect)
                        if (eL) r.left = x
                        if (eR) r.right = x
                        if (eT) r.top = y
                        if (eB) r.bottom = y
                        val mn = dp(52f)
                        if (r.width() >= mn && r.height() >= mn) rect.set(r)
                    }
                    Drag.LASSO -> {
                        lassoPts.add(PointF(x, y))
                        lassoPath.lineTo(x, y)
                    }
                    Drag.NONE -> {}
                }
                invalidate()
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                when (drag) {
                    Drag.NEW -> {
                        if (rect.width() > dp(24f) && rect.height() > dp(24f)) {
                            hasSelection = true
                            popHandles()
                            onSelectionChanged?.invoke(true)
                        } else {
                            clearSelection()
                        }
                    }
                    Drag.LASSO -> {
                        lassoPath.close()
                        val b = RectF()
                        lassoPath.computeBounds(b, true)
                        if (b.width() > dp(24f) && b.height() > dp(24f)) {
                            hasSelection = true
                            onSelectionChanged?.invoke(true)
                        } else {
                            clearSelection()
                        }
                    }
                    Drag.MOVE, Drag.RESIZE -> onSelectionChanged?.invoke(true)
                    Drag.NONE -> {}
                }
                drawing = false
                drag = Drag.NONE
                invalidate()
            }
        }
        return true
    }

    private fun startNew(x: Float, y: Float) {
        val had = hasSelection
        hasSelection = false
        drag = Drag.NEW
        drawing = true
        ax = x
        ay = y
        rect.set(x, y, x, y)
        if (had) onSelectionChanged?.invoke(false)
    }

    private fun startLasso(x: Float, y: Float) {
        val had = hasSelection
        hasSelection = false
        drag = Drag.LASSO
        drawing = true
        lassoPts.clear()
        lassoPath.reset()
        lassoPath.moveTo(x, y)
        lassoPts.add(PointF(x, y))
        if (had) onSelectionChanged?.invoke(false)
    }

    /** Cuts the selected shape out of the full-resolution screenshot. */
    fun crop(src: Bitmap): Bitmap? {
        if (!hasSelection || width == 0 || height == 0) return null
        val m = Matrix()
        m.setScale(src.width / width.toFloat(), src.height / height.toFloat())
        val sp = Path()
        selectionPath().transform(m, sp)
        val b = RectF()
        sp.computeBounds(b, true)
        val l = b.left.toInt().coerceIn(0, src.width - 1)
        val t = b.top.toInt().coerceIn(0, src.height - 1)
        val r = ceil(b.right).toInt().coerceIn(l + 1, src.width)
        val bt = ceil(b.bottom).toInt().coerceIn(t + 1, src.height)
        val out = Bitmap.createBitmap(r - l, bt - t, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.translate(-l.toFloat(), -t.toFloat())
        if (mode != Mode.RECT) canvas.clipPath(sp)
        canvas.drawBitmap(src, 0f, 0f, null)
        return out
    }
}
