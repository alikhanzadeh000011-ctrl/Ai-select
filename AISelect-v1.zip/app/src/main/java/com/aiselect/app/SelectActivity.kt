package com.aiselect.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils
import android.transition.TransitionManager
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.window.OnBackInvokedDispatcher
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.FileOutputStream

class SelectActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var selection: SelectionView
    private lateinit var glow: GlowView
    private lateinit var toolbar: LinearLayout
    private lateinit var actions: LinearLayout
    private lateinit var shapeButtons: List<Pair<ImageView, Triple<SelectionView.Mode, Int, Int>>>
    private lateinit var textCapsule: LinearLayout
    private lateinit var textIcon: ImageView
    private lateinit var lottie: LottieAnimationView
    private lateinit var guide: TextView
    private var resultPanel: View? = null
    private var shot: Bitmap? = null
    private var busy = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bmp = ShotHolder.bitmap
        if (bmp == null) {
            finish()
            return
        }
        shot = bmp

        WindowCompat.setDecorFitsSystemWindows(window, false)
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        window.attributes = lp
        val ctrl = WindowInsetsControllerCompat(window, window.decorView)
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        val img = ImageView(this)
        img.setImageBitmap(bmp)
        img.scaleType = ImageView.ScaleType.FIT_XY
        root.addView(img, FrameLayout.LayoutParams(match, match))

        glow = GlowView(this)
        root.addView(glow, FrameLayout.LayoutParams(match, match))

        selection = SelectionView(this)
        root.addView(selection, FrameLayout.LayoutParams(match, match))

        // guide text (ai_select_guide_text_*)
        guide = TextView(this)
        guide.text = "Draw around what you want to select"
        guide.setTextColor(Color.WHITE)
        guide.setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), 0xCC000000.toInt())
        guide.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f)
        guide.gravity = Gravity.CENTER
        val gl = FrameLayout.LayoutParams(wrap, wrap, Gravity.CENTER_HORIZONTAL or Gravity.TOP)
        gl.topMargin = dp(90)
        root.addView(guide, gl)

        // close button
        val close = TextView(this)
        close.text = "\u2715"
        close.gravity = Gravity.CENTER
        close.setTextColor(0xFF010102.toInt())
        close.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15f)
        close.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xCCFFFFFF.toInt())
        }
        close.setOnClickListener { finish() }
        val cl = FrameLayout.LayoutParams(dp(32), dp(32), Gravity.TOP or Gravity.END)
        cl.topMargin = dp(44)
        cl.marginEnd = dp(24)
        root.addView(close, cl)

        buildToolbar()
        buildTextCapsule()

        val tl = FrameLayout.LayoutParams(wrap, dp(52), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        tl.bottomMargin = dp(36)
        root.addView(toolbar, tl)

        val tcl = FrameLayout.LayoutParams(wrap, dp(36), Gravity.TOP or Gravity.START)
        root.addView(textCapsule, tcl)

        selection.onInteractionStart = {
            if (guide.alpha > 0f) guide.animate().alpha(0f).setDuration(200).start()
        }
        selection.onSelectionChanged = { has -> onSelectionState(has) }

        setContentView(root)

        onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT) {
            handleBack()
        }

        glow.pulse(1300)
        guide.postDelayed({ guide.animate().alpha(0f).setDuration(400).start() }, 3500)
    }

    // ---------- UI ----------

    private fun buildToolbar() {
        toolbar = LinearLayout(this)
        toolbar.orientation = LinearLayout.HORIZONTAL
        toolbar.gravity = Gravity.CENTER_VERTICAL
        toolbar.setPadding(dp(9), dp(5), dp(9), dp(5))
        toolbar.elevation = dp(4).toFloat()
        // smart_select_toolbar_background_start / end, radius 28dp
        toolbar.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xF2DEDEE1.toInt(), 0xF2C9C9CC.toInt())
        ).apply { cornerRadius = dp(28).toFloat() }

        val defs = listOf(
            Triple(SelectionView.Mode.RECT, R.drawable.shape_rect, R.drawable.shape_rect_sel),
            Triple(SelectionView.Mode.OVAL, R.drawable.shape_oval, R.drawable.shape_oval_sel),
            Triple(SelectionView.Mode.LASSO, R.drawable.shape_lasso, R.drawable.shape_lasso_sel)
        )
        val list = ArrayList<Pair<ImageView, Triple<SelectionView.Mode, Int, Int>>>()
        for (def in defs) {
            val v = ImageView(this)
            v.scaleType = ImageView.ScaleType.FIT_CENTER
            v.setPadding(dp(4), dp(4), dp(4), dp(4))
            v.setOnClickListener {
                selection.mode = def.first
                refreshShapeIcons()
            }
            toolbar.addView(v, LinearLayout.LayoutParams(dp(42), dp(42)))
            list.add(Pair(v, def))
        }
        shapeButtons = list
        refreshShapeIcons()

        actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.gravity = Gravity.CENTER_VERTICAL
        actions.visibility = View.GONE

        val divider = View(this)
        divider.setBackgroundColor(0x33000000)
        val dl = LinearLayout.LayoutParams(dp(1), dp(24))
        dl.marginStart = dp(6)
        dl.marginEnd = dp(6)
        actions.addView(divider, dl)

        actions.addView(actionButton(R.drawable.ic_copy) { doCopy() }, LinearLayout.LayoutParams(dp(42), dp(42)))
        actions.addView(actionButton(R.drawable.ic_save) { doSave() }, LinearLayout.LayoutParams(dp(42), dp(42)))
        actions.addView(actionButton(R.drawable.ic_share) { doShare() }, LinearLayout.LayoutParams(dp(42), dp(42)))
        toolbar.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun actionButton(res: Int, onClick: () -> Unit): ImageView {
        val v = ImageView(this)
        v.setImageResource(res)
        v.imageTintList = ColorStateList.valueOf(0xFF444444.toInt())
        v.scaleType = ImageView.ScaleType.FIT_CENTER
        v.setPadding(dp(11), dp(11), dp(11), dp(11))
        v.setOnClickListener { onClick() }
        return v
    }

    private fun refreshShapeIcons() {
        for ((view, def) in shapeButtons) {
            view.setImageResource(if (selection.mode == def.first) def.third else def.second)
        }
    }

    private fun buildTextCapsule() {
        textCapsule = LinearLayout(this)
        textCapsule.orientation = LinearLayout.HORIZONTAL
        textCapsule.gravity = Gravity.CENTER_VERTICAL
        textCapsule.setPadding(dp(10), 0, dp(12), 0)
        textCapsule.elevation = dp(4).toFloat()
        // ai_select_capsule_background_gradient_color_start / middle / end, radius 21dp
        textCapsule.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xFF8BBDFF.toInt(), 0xFF88E6E3.toInt(), 0xFFBDFAA5.toInt())
        ).apply { cornerRadius = dp(21).toFloat() }
        textCapsule.visibility = View.GONE

        val iconBox = FrameLayout(this)
        textIcon = ImageView(this)
        textIcon.setImageResource(R.drawable.ic_text)
        textIcon.imageTintList = ColorStateList.valueOf(0xFF010102.toInt())
        iconBox.addView(textIcon, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))

        lottie = LottieAnimationView(this)
        lottie.setAnimation(R.raw.intelligence_progress_color)
        lottie.repeatCount = LottieDrawable.INFINITE
        lottie.visibility = View.INVISIBLE
        iconBox.addView(lottie, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        textCapsule.addView(iconBox, LinearLayout.LayoutParams(dp(22), dp(22)))

        val label = TextView(this)
        label.text = "Extract text"
        label.setTextColor(0xFF010102.toInt())
        label.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f)
        label.maxLines = 1
        label.ellipsize = TextUtils.TruncateAt.END
        val ll = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        ll.marginStart = dp(4)
        textCapsule.addView(label, ll)

        textCapsule.setOnClickListener { extractText() }
    }

    private fun onSelectionState(has: Boolean) {
        TransitionManager.beginDelayedTransition(root)
        actions.visibility = if (has) View.VISIBLE else View.GONE
        if (has) {
            placeCapsule()
            if (textCapsule.visibility != View.VISIBLE) {
                textCapsule.visibility = View.VISIBLE
                textCapsule.scaleX = 0.6f
                textCapsule.scaleY = 0.6f
                springTo(textCapsule, DynamicAnimation.SCALE_X, 1f)
                springTo(textCapsule, DynamicAnimation.SCALE_Y, 1f)
            }
        } else {
            textCapsule.visibility = View.GONE
        }
    }

    private fun springTo(v: View, prop: DynamicAnimation.ViewProperty, target: Float) {
        val sa = SpringAnimation(v, prop, target)
        sa.spring.setStiffness(SpringForce.STIFFNESS_MEDIUM)
        sa.spring.setDampingRatio(SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY)
        sa.start()
    }

    private fun placeCapsule() {
        val b = RectF()
        selection.selectionBounds(b)
        textCapsule.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = textCapsule.measuredWidth
        val h = dp(36)
        val rw = if (root.width > 0) root.width else resources.displayMetrics.widthPixels
        val rh = if (root.height > 0) root.height else resources.displayMetrics.heightPixels
        val x = (b.centerX() - w / 2f).coerceIn(dp(10).toFloat(), (rw - w - dp(10)).toFloat().coerceAtLeast(dp(10).toFloat()))
        var y = b.bottom + dp(14)
        val toolbarTop = rh - dp(36) - dp(52)
        if (y + h > toolbarTop - dp(8)) y = b.top - h - dp(14)
        if (y < dp(40)) y = b.top + dp(10)
        textCapsule.translationX = x
        textCapsule.translationY = y
    }

    // ---------- actions ----------

    private fun currentCrop(): Bitmap? {
        val s = shot ?: return null
        return selection.crop(s)
    }

    private fun cacheUri(bmp: Bitmap): Uri {
        val dir = File(cacheDir, "shared")
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }
        val f = File(dir, "aiselect_${System.currentTimeMillis()}.png")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return FileProvider.getUriForFile(this, "$packageName.files", f)
    }

    private fun doCopy() {
        val bmp = currentCrop() ?: return
        val uri = cacheUri(bmp)
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newUri(contentResolver, "AI Select", uri))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun doSave() {
        val bmp = currentCrop() ?: return
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "AISelect_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI Select")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            Toast.makeText(this, "Couldn't save", Toast.LENGTH_SHORT).show()
            return
        }
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
        Toast.makeText(this, "Saved to Pictures/AI Select", Toast.LENGTH_SHORT).show()
    }

    private fun doShare() {
        val bmp = currentCrop() ?: return
        val uri = cacheUri(bmp)
        val i = android.content.Intent(android.content.Intent.ACTION_SEND)
        i.type = "image/png"
        i.putExtra(android.content.Intent.EXTRA_STREAM, uri)
        i.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(android.content.Intent.createChooser(i, null))
    }

    private fun extractText() {
        if (busy) return
        val crop = currentCrop() ?: return
        busy = true
        textIcon.visibility = View.INVISIBLE
        lottie.visibility = View.VISIBLE
        lottie.playAnimation()
        glow.start()
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        rec.process(InputImage.fromBitmap(crop, 0))
            .addOnSuccessListener { r ->
                endOcr()
                showResult(r.text.trim())
            }
            .addOnFailureListener {
                endOcr()
                showResult("")
            }
    }

    private fun endOcr() {
        busy = false
        lottie.cancelAnimation()
        lottie.visibility = View.INVISIBLE
        textIcon.visibility = View.VISIBLE
        glow.stop()
    }

    private fun showResult(text: String) {
        hideResult()
        val empty = text.isEmpty()
        val panel = FrameLayout(this)
        // smart_select_meta_text_card_view_dim_color
        panel.setBackgroundColor(0x33000000)
        panel.setOnClickListener { hideResult() }

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(24), dp(24), dp(24), dp(16))
        card.elevation = dp(8).toFloat()
        card.isClickable = true
        card.background = GradientDrawable().apply {
            setColor(0xFFFCFCFC.toInt())
            cornerRadius = dp(28).toFloat()
        }

        val title = TextView(this)
        title.text = "Text"
        title.setTextColor(0xFF010101.toInt())
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        title.typeface = Typeface.DEFAULT_BOLD
        card.addView(title)

        val body = TextView(this)
        body.text = if (empty) "No text found in the selection" else text
        body.setTextColor(if (empty) 0xFF848487.toInt() else 0xFF505050.toInt())
        body.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        body.setLineSpacing(dp(4).toFloat(), 1f)
        body.setTextIsSelectable(!empty)
        val scroll = ScrollView(this)
        scroll.addView(body)
        val sl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        sl.topMargin = dp(18)
        sl.bottomMargin = dp(12)
        card.addView(scroll, sl)
        body.viewTreeObserver.addOnGlobalLayoutListener {
            val maxH = dp(213)
            if (scroll.height > maxH) {
                val p = scroll.layoutParams
                p.height = maxH
                scroll.layoutParams = p
            }
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.END
        if (!empty) {
            row.addView(textButton("Copy") {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("AI Select", text))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            })
            row.addView(textButton("Share") {
                val i = android.content.Intent(android.content.Intent.ACTION_SEND)
                i.type = "text/plain"
                i.putExtra(android.content.Intent.EXTRA_TEXT, text)
                startActivity(android.content.Intent.createChooser(i, null))
            })
        }
        row.addView(textButton("Close") { hideResult() })
        card.addView(row)

        val cl = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        cl.marginStart = dp(12)
        cl.marginEnd = dp(12)
        cl.bottomMargin = dp(20)
        panel.addView(card, cl)

        root.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        resultPanel = panel
        card.translationY = dp(500).toFloat()
        val sa = SpringAnimation(card, DynamicAnimation.TRANSLATION_Y, 0f)
        sa.spring.setStiffness(SpringForce.STIFFNESS_LOW)
        sa.spring.setDampingRatio(SpringForce.DAMPING_RATIO_LOW_BOUNCY)
        sa.start()
    }

    private fun textButton(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(0xFF010101.toInt())
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        t.setPadding(dp(14), dp(8), dp(14), dp(8))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun hideResult() {
        resultPanel?.let { root.removeView(it) }
        resultPanel = null
    }

    private fun handleBack() {
        if (resultPanel != null) hideResult() else finish()
    }

    override fun onDestroy() {
        if (isFinishing) ShotHolder.bitmap = null
        super.onDestroy()
    }
}
