package com.aiselect.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

/** Invisible hop used by the Quick Settings tile: lets the shade close, then captures. */
class TriggerActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val service = AISelectService.instance
        if (service == null) {
            Toast.makeText(this, "Turn on AI Select in Accessibility settings first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else {
            service.captureDelayed(450)
        }
        finish()
    }
}
