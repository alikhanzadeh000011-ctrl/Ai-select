package com.aiselect.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * Takes the screenshot (no MediaProjection prompt needed) and opens [SelectActivity].
 * It only runs when you trigger it; it does not read or store anything from the screen.
 */
class AISelectService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AISelectService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var busy = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    fun captureDelayed(delayMs: Long) {
        handler.postDelayed({ capture() }, delayMs)
    }

    private fun capture() {
        if (busy) return
        busy = true
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                try {
                    val buffer = result.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                    val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hw?.recycle()
                    buffer.close()
                    if (soft != null) {
                        ShotHolder.bitmap = soft
                        val i = Intent(this@AISelectService, SelectActivity::class.java)
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                        startActivity(i)
                    }
                } finally {
                    busy = false
                }
            }

            override fun onFailure(errorCode: Int) {
                busy = false
                Toast.makeText(this@AISelectService, "Screenshot failed (code $errorCode)", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
