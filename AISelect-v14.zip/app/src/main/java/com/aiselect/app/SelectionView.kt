package com.aiselect.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuffXfermode
import android.graphics.PorterDuff
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * AI Select selection layer: draw any stroke around something, it snaps into a glowing
 * rounded square with four thick, differently tinted corner arcs; it can be moved and resized.
 */
class SelectionView(context: Context) : View(context) {

    enum class State { IDLE, DRAWING, SELECTED }

    var state: State = State.IDLE
        private set

    var onTouchStart: (() -> Unit)? = null
    var onSelected: ((RectF) -> Unit)? = null
    var onRectChanged: ((RectF) -> Unit)? = null
    var onCleared: (() -> Unit)? = null

    private val rect = RectF()
    private val strokePath = Path()
    private val leftPath = Path()
    private val rightPath = Path()
    private var hasEdges = false
    private var prevNx = 0f
    private var prevNy = 0f
    private var plx = 0f
    private var ply = 0f
    private var prx = 0f
    private var pry = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var startX = 0f
    private var startY = 0f
    private var minX = 0f
    private var minY = 0f
    private var maxX = 0f
    private var maxY = 0f

    private enum class Drag { NONE, STROKE, MOVE, RESIZE }

    private var drag = Drag.NONE
    private var eL = false
    private var eR = false
    private var eT = false
    private var eB = false
    private var ax = 0f
    private var ay = 0f

    private var dimAlpha = 0f
    private var dimAnim: ValueAnimator? = null
    private var strokeAlpha = 0f
    private var selProgress = 1f
    private var spring: SpringAnimation? = null

    private class Dust(val x: Float, val y: Float, val vx: Float, val vy: Float, val born: Long, val life: Long, val size: Float, val color: Int)

    private val dust = ArrayList<Dust>()

    private val dimPaint = Paint().apply { color = 0xFF000000.toInt() }
    private val bandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val blurPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = 0xFF050C10.toInt()
    }
    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    /** 1 = thick corner arcs visible; they vanish while the square is being held/moved. */
    private var arcFactor = 1f
    private var arcAnim: ValueAnimator? = null
    var onDragStart: (() -> Unit)? = null
    private var edgeBack = false

    private fun animateArcs(to: Float, ms: Long, delay: Long) {
        arcAnim?.cancel()
        val a = ValueAnimator.ofFloat(arcFactor, to)
        a.duration = ms
        a.startDelay = delay
        a.addUpdateListener {
            arcFactor = it.animatedValue as Float
            invalidate()
        }
        arcAnim = a
        a.start()
    }

    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dustPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    // handler tint colors from the original resources
    private val cTl = 0xFF88B6FE.toInt()
    private val cTr = 0xFF8EDEE6.toInt()
    private val cBl = 0xFF8BCDF0.toInt()
    private val cBr = 0xFF7EE1B1.toInt()

    private val sweepColors = intArrayOf(
        0xFFD7EFB0.toInt(), 0xFF7EE1B1.toInt(), 0xFFC5EFC8.toInt(), 0xFF8BCDF0.toInt(),
        0xFF86AEFF.toInt(), 0xFF7EA6FF.toInt(), 0xFFA8D0F8.toInt(), 0xFF8EDEE6.toInt(), 0xFFD7EFB0.toInt()
    )

    init {
        haloPaint.maskFilter = BlurMaskFilter(context.u(40f), BlurMaskFilter.Blur.NORMAL)
        blurPaint.maskFilter = BlurMaskFilter(context.u(26f), BlurMaskFilter.Blur.NORMAL)
    }

    private fun u(px: Float) = context.u(px)

    companion object {
        const val IDLE_DIM = 0.0f
        const val DRAW_DIM = 0.16f
        const val SEL_DIM = 0.16f
    }

    private fun animateDim(to: Float) {
        dimAnim?.cancel()
        val a = ValueAnimator.ofFloat(dimAlpha, to)
        a.duration = 240
        a.addUpdateListener {
            dimAlpha = it.animatedValue as Float
            invalidate()
        }
        dimAnim = a
        a.start()
    }

    fun showIdleDim() {
        animateDim(IDLE_DIM)
    }

    fun clearSelection() {
        val had = state != State.IDLE
        arcAnim?.cancel()
        arcFactor = 1f
        state = State.IDLE
        drag = Drag.NONE
        strokePath.reset()
        strokeAlpha = 0f
        dust.clear()
        animateDim(IDLE_DIM)
        invalidate()
        if (had) onCleared?.invoke()
    }

    private fun radius() = u(80f)

    private fun roundRect(r: RectF): Path {
        val p = Path()
        val rad = min(radius(), min(r.width(), r.height()) / 2f)
        p.addRoundRect(r, rad, rad, Path.Direction.CW)
        return p
    }

    private fun currentRect(): RectF {
        val k = 0.94f + 0.06f * selProgress.coerceIn(0f, 1.15f)
        val cx = rect.centerX()
        val cy = rect.centerY()
        val w = rect.width() * k
        val h = rect.height() * k
        return RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val now = SystemClock.uptimeMillis()

        dimPaint.alpha = (dimAlpha.coerceIn(0f, 1f) * 255).toInt()
        if (state == State.SELECTED) {
            val rc = currentRect()
            c.save()
            c.clipOutPath(roundRect(rc))
            c.drawRect(0f, 0f, w, h, dimPaint)
            c.restore()
            drawSelection(c, rc)
        } else {
            c.drawRect(0f, 0f, w, h, dimPaint)
        }

        if (strokeAlpha > 0.01f && !strokePath.isEmpty) {
            val ex = if (abs(lastX - startX) < 1f) startX + 1f else lastX
            val g = LinearGradient(startX, startY, ex, lastY, 0xFF86BDF5.toInt(), 0xFF72D9B6.toInt(), Shader.TileMode.CLAMP)
            val lay = c.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)
            // wide soft light spreading out of the line (blue at the start, mint at the end)
            blurPaint.shader = g
            blurPaint.strokeWidth = u(70f)
            blurPaint.alpha = (0.85f * strokeAlpha * 255).toInt()
            c.drawPath(strokePath, blurPaint)
            haloPaint.shader = g
            haloPaint.strokeCap = Paint.Cap.ROUND
            haloPaint.strokeWidth = u(34f)
            haloPaint.alpha = (0.75f * strokeAlpha * 255).toInt()
            c.drawPath(strokePath, haloPaint)
            // cut the line itself out of the light: the line is see-through
            clearPaint.strokeWidth = u(15f)
            c.drawPath(strokePath, clearPaint)
            c.restoreToCount(lay)
            // only a faint darkening so the line can be read, everything stays visible behind it
            corePaint.color = 0xFF020A0E.toInt()
            corePaint.strokeWidth = u(15f)
            corePaint.alpha = (0.22f * strokeAlpha * 255).toInt()
            c.drawPath(strokePath, corePaint)
        }

        if (dust.isNotEmpty()) {
            val iter = dust.iterator()
            while (iter.hasNext()) {
                val d = iter.next()
                val t = (now - d.born).toFloat() / d.life
                if (t >= 1f) {
                    iter.remove()
                    continue
                }
                dustPaint.color = d.color
                dustPaint.alpha = ((1f - t) * 0.9f * 255).toInt()
                val ds = d.size * (1f - 0.4f * t)
                val dxp = d.x + d.vx * t
                val dyp = d.y + d.vy * t
                c.drawRect(dxp - ds, dyp - ds, dxp + ds, dyp + ds, dustPaint)
            }
            postInvalidateOnAnimation()
        }
    }

    private fun drawSelection(c: Canvas, rc: RectF) {
        val a = selProgress.coerceIn(0f, 1f)
        val p = roundRect(rc)
        val sweep = SweepGradient(rc.centerX(), rc.centerY(), sweepColors, null)

        // light spreading outwards only: nothing inside the square
        c.save()
        c.clipOutPath(p)
        haloPaint.shader = sweep
        haloPaint.strokeWidth = u(46f)
        haloPaint.alpha = (0.75f * a * 255).toInt()
        c.drawPath(p, haloPaint)
        haloPaint.strokeWidth = u(20f)
        haloPaint.alpha = (0.55f * a * 255).toInt()
        c.drawPath(p, haloPaint)
        c.restore()

        // thin outline
        outlinePaint.shader = sweep
        outlinePaint.strokeWidth = u(5f)
        outlinePaint.alpha = (a * 255).toInt()
        c.drawPath(p, outlinePaint)

        // thick corner arcs, appear a moment after the outline
        val ba = ((selProgress - 0.35f) / 0.65f).coerceIn(0f, 1f) * arcFactor
        if (ba > 0f) {
            val rad = min(radius(), min(rc.width(), rc.height()) / 2f)
            val d = rad * 2f
            arcPaint.strokeWidth = u(14f)
            arcPaint.alpha = (ba * 255).toInt()
            arcPaint.color = cTl
            arcPaint.alpha = (ba * 255).toInt()
            c.drawArc(RectF(rc.left, rc.top, rc.left + d, rc.top + d), 180f, 90f, false, arcPaint)
            arcPaint.color = cTr
            arcPaint.alpha = (ba * 255).toInt()
            c.drawArc(RectF(rc.right - d, rc.top, rc.right, rc.top + d), 270f, 90f, false, arcPaint)
            arcPaint.color = cBr
            arcPaint.alpha = (ba * 255).toInt()
            c.drawArc(RectF(rc.right - d, rc.bottom - d, rc.right, rc.bottom), 0f, 90f, false, arcPaint)
            arcPaint.color = cBl
            arcPaint.alpha = (ba * 255).toInt()
            c.drawArc(RectF(rc.left, rc.bottom - d, rc.left + d, rc.bottom), 90f, 90f, false, arcPaint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x.coerceIn(0f, width.toFloat())
        val y = e.y.coerceIn(0f, height.toFloat())

        // a touch that starts inside the system back-gesture zone at the left/right edge never draws a line:
        // it is left to Samsung's own back gesture
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            val ez = u(90f)
            val atEdge = x < ez || x > width - ez
            val t = u(56f)
            val onRect = state == State.SELECTED &&
                x >= rect.left - t && x <= rect.right + t && y >= rect.top - t && y <= rect.bottom + t
            if (atEdge && !onRect) {
                edgeBack = true
                return true
            }
        }
        if (edgeBack) {
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) edgeBack = false
            return true
        }

        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                if (state == State.SELECTED) {
                    val t = u(56f)
                    val inside = x >= rect.left - t && x <= rect.right + t && y >= rect.top - t && y <= rect.bottom + t
                    val dl = abs(x - rect.left)
                    val dr = abs(x - rect.right)
                    val dt = abs(y - rect.top)
                    val db = abs(y - rect.bottom)
                    eL = dl < t && dl <= dr
                    eR = dr < t && !eL
                    eT = dt < t && dt <= db
                    eB = db < t && !eT
                    if (inside && (eL || eR || eT || eB)) {
                        drag = Drag.RESIZE
                        animateArcs(0f, 90, 0)
                        onDragStart?.invoke()
                    } else if (rect.contains(x, y)) {
                        drag = Drag.MOVE
                        ax = x
                        ay = y
                        animateArcs(0f, 90, 0)
                        onDragStart?.invoke()
                    } else {
                        startStroke(x, y)
                    }
                } else {
                    startStroke(x, y)
                }
            }

            MotionEvent.ACTION_MOVE -> {
                when (drag) {
                    Drag.STROKE -> {
                        val mx = (lastX + x) / 2f
                        val my = (lastY + y) / 2f
                        strokePath.quadTo(lastX, lastY, mx, my)
                        addEdges(x, y)
                        lastX = x
                        lastY = y
                        minX = min(minX, x)
                        minY = min(minY, y)
                        maxX = max(maxX, x)
                        maxY = max(maxY, y)
                        spawnDust(x, y)
                    }
                    Drag.MOVE -> {
                        val w = rect.width()
                        val h = rect.height()
                        val l = (rect.left + (x - ax)).coerceIn(0f, max(0f, width - w))
                        val t = (rect.top + (y - ay)).coerceIn(0f, max(0f, height - h))
                        rect.set(l, t, l + w, t + h)
                        ax = x
                        ay = y
                        onRectChanged?.invoke(RectF(rect))
                    }
                    Drag.RESIZE -> {
                        val r = RectF(rect)
                        if (eL) r.left = x
                        if (eR) r.right = x
                        if (eT) r.top = y
                        if (eB) r.bottom = y
                        val mn = u(200f)
                        if (r.width() >= mn && r.height() >= mn) {
                            rect.set(r)
                            onRectChanged?.invoke(RectF(rect))
                        }
                    }
                    Drag.NONE -> {}
                }
                invalidate()
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                when (drag) {
                    Drag.STROKE -> if (e.actionMasked == MotionEvent.ACTION_CANCEL) clearSelection() else finishStroke()
                    Drag.MOVE, Drag.RESIZE -> {
                        animateArcs(1f, 140, 40)
                        onSelected?.invoke(RectF(rect))
                    }
                    Drag.NONE -> {}
                }
                drag = Drag.NONE
                invalidate()
            }
        }
        return true
    }

    private fun startStroke(x: Float, y: Float) {
        onTouchStart?.invoke()
        arcAnim?.cancel()
        arcFactor = 1f
        val had = state == State.SELECTED
        state = State.DRAWING
        drag = Drag.STROKE
        leftPath.reset()
        rightPath.reset()
        hasEdges = false
        prevNx = 0f
        prevNy = 0f
        strokePath.reset()
        strokePath.moveTo(x, y)
        lastX = x
        lastY = y
        startX = x
        startY = y
        minX = x
        maxX = x
        minY = y
        maxY = y
        strokeAlpha = 1f
        animateDim(DRAW_DIM)
        if (had) onCleared?.invoke()
    }

    private fun finishStroke() {
        val w = maxX - minX
        val h = maxY - minY
        if (w > u(110f) && h > u(110f)) {
            rect.set(minX, minY, maxX, maxY)
            rect.inset(-u(14f), -u(14f))
            rect.intersect(0f, 0f, width.toFloat(), height.toFloat())
            val mn = u(240f)
            if (rect.width() < mn) rect.inset(-(mn - rect.width()) / 2f, 0f)
            if (rect.height() < mn) rect.inset(0f, -(mn - rect.height()) / 2f)
            rect.intersect(0f, 0f, width.toFloat(), height.toFloat())
            state = State.SELECTED
            animateDim(SEL_DIM)
            val fade = ValueAnimator.ofFloat(1f, 0f)
            fade.duration = 220
            fade.addUpdateListener {
                strokeAlpha = it.animatedValue as Float
                invalidate()
            }
            fade.start()
            spring?.cancel()
            selProgress = 0f
            val sa = SpringAnimation(FloatValueHolder(0f))
            sa.setSpring(
                SpringForce(1f)
                    .setStiffness(SpringForce.STIFFNESS_MEDIUM)
                    .setDampingRatio(SpringForce.DAMPING_RATIO_LOW_BOUNCY)
            )
            sa.setStartValue(0f)
            sa.addUpdateListener { _, value, _ ->
                selProgress = value
                invalidate()
            }
            spring = sa
            sa.start()
            onSelected?.invoke(RectF(rect))
        } else {
            val fade = ValueAnimator.ofFloat(1f, 0f)
            fade.duration = 200
            fade.addUpdateListener {
                strokeAlpha = it.animatedValue as Float
                invalidate()
            }
            fade.start()
            state = State.IDLE
            animateDim(IDLE_DIM)
            onCleared?.invoke()
        }
    }

    /** Builds the two edge lines of the glass tube (left side dark, right side white). */
    private fun addEdges(x: Float, y: Float) {
        val dx = x - lastX
        val dy = y - lastY
        val len = kotlin.math.sqrt(dx * dx + dy * dy)
        if (len < u(3f)) return
        var nx = -dy / len
        var ny = dx / len
        if (prevNx != 0f || prevNy != 0f) {
            nx = prevNx * 0.6f + nx * 0.4f
            ny = prevNy * 0.6f + ny * 0.4f
            val l2 = kotlin.math.sqrt(nx * nx + ny * ny)
            if (l2 > 0.001f) {
                nx /= l2
                ny /= l2
            }
        }
        prevNx = nx
        prevNy = ny
        val d = u(26f)
        val lx = x - nx * d
        val ly = y - ny * d
        val rx = x + nx * d
        val ry = y + ny * d
        if (!hasEdges) {
            leftPath.moveTo(lx, ly)
            rightPath.moveTo(rx, ry)
            hasEdges = true
        } else {
            leftPath.quadTo(plx, ply, (plx + lx) / 2f, (ply + ly) / 2f)
            rightPath.quadTo(prx, pry, (prx + rx) / 2f, (pry + ry) / 2f)
        }
        plx = lx
        ply = ly
        prx = rx
        pry = ry
    }

    private fun spawnDust(x: Float, y: Float) {
        val now = SystemClock.uptimeMillis()
        for (i in 0 until 4) {
            dust.add(
                Dust(
                    x + Random.nextFloat() * u(80f) - u(40f),
                    y + Random.nextFloat() * u(80f) - u(40f),
                    Random.nextFloat() * u(30f) - u(15f),
                    -Random.nextFloat() * u(40f),
                    now,
                    450L + Random.nextLong(500L),
                    u(1.2f) + Random.nextFloat() * u(2.4f),
                    if (Random.nextBoolean()) 0xFFD6FFF0.toInt() else 0xFFBFE6FF.toInt()
                )
            )
        }
        if (dust.size > 220) dust.subList(0, dust.size - 220).clear()
    }

    /** Cuts the selected rectangle out of the full-resolution screenshot. */
    fun crop(src: Bitmap): Bitmap? {
        if (state != State.SELECTED || width == 0 || height == 0) return null
        val sx = src.width / width.toFloat()
        val sy = src.height / height.toFloat()
        val l = (rect.left * sx).toInt().coerceIn(0, src.width - 1)
        val t = (rect.top * sy).toInt().coerceIn(0, src.height - 1)
        val r = (rect.right * sx).toInt().coerceIn(l + 1, src.width)
        val b = (rect.bottom * sy).toInt().coerceIn(t + 1, src.height)
        return Bitmap.createBitmap(src, l, t, r - l, b - t)
    }

    fun selectedRect(): RectF = RectF(rect)
}
