package com.aiselect.app

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/**
 * Entry effects: the pastel color wash and the glowing rim around the screen edge.
 * The rim colors (yellow, mint, blue, lavender) slowly travel around the screen.
 */
class RimView(context: Context) : View(context) {

    var rimAlpha: Float = 0f
        set(v) {
            field = v
            invalidate()
        }
    var washAlpha: Float = 0f
        set(v) {
            field = v
            invalidate()
        }
    var washPhase: Float = 0f
        set(v) {
            field = v
            invalidate()
        }
    var rimPhase: Float = 0f
        set(v) {
            field = v
            invalidate()
        }
    var tintAlpha: Float = 0f
        set(v) {
            field = v
            invalidate()
        }

    /** 0..1: how far the splash has spread from (revealCx, revealCy); 1 = everywhere. */
    var reveal: Float = 1f
        set(v) {
            field = v
            invalidate()
        }
    var revealCx = 0f
    var revealCy = 0f
    private val maskPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }

    private val bandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val washPaint = Paint()
    private val tintPaint = Paint()
    private val path = Path()
    private val m = Matrix()
    private var sweep: SweepGradient? = null

    // measured from the original: top yellow, right mint-cyan, bottom lavender, left cyan
    private val rimColors = intArrayOf(
        0xFF8EE8DC.toInt(), 0xFFBEB3FF.toInt(), 0xFF89DCEA.toInt(), 0xFFEDF48A.toInt(), 0xFF8EE8DC.toInt()
    )
    private val washColors = intArrayOf(
        0xFFF4F4A0.toInt(), 0xFFA5E6D2.toInt(), 0xFF9DB4FF.toInt(), 0xFFC7A6FF.toInt()
    )

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        sweep = SweepGradient(w / 2f, h / 2f, rimColors, null)
        bandPaint.shader = sweep
        glowPaint.shader = sweep
        bandPaint.strokeWidth = context.u(16f)
        glowPaint.strokeWidth = context.u(26f)
        glowPaint.maskFilter = BlurMaskFilter(context.u(14f), BlurMaskFilter.Blur.NORMAL)
        // idle tint: faint at the top, teal in the lower half, blue at the bottom (measured from the original)
        tintPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(
                0x0A8FDECB, 0x0D8FDECB, 0x59B9E9CD, 0x7360CFD7, 0x7360CFD7, 0x8C69BEFF.toInt(), 0x8F69BEFF.toInt()
            ),
            floatArrayOf(0f, 0.064f, 0.43f, 0.73f, 0.81f, 0.96f, 1f), Shader.TileMode.CLAMP
        )
        path.reset()
        val r = context.u(95f)
        path.addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, Path.Direction.CW)
    }

    override fun onDraw(c: Canvas) {
        if (reveal >= 0.999f) {
            drawContent(c)
            return
        }
        val w = width.toFloat()
        val h = height.toFloat()
        val dx = maxOf(revealCx, w - revealCx)
        val dy = maxOf(revealCy, h - revealCy)
        val maxR = kotlin.math.sqrt(dx * dx + dy * dy)
        val feather = context.u(180f)
        val r = (reveal * (maxR + feather)).coerceAtLeast(1f)
        val solid = ((r - feather) / r).coerceIn(0f, 0.999f)
        maskPaint.shader = RadialGradient(
            revealCx, revealCy, r,
            intArrayOf(0xFF000000.toInt(), 0xFF000000.toInt(), 0x00000000),
            floatArrayOf(0f, solid, 1f), Shader.TileMode.CLAMP
        )
        val sc = c.saveLayer(0f, 0f, w, h, null)
        drawContent(c)
        c.drawRect(0f, 0f, w, h, maskPaint)
        c.restoreToCount(sc)
    }

    private fun drawContent(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (tintAlpha > 0.001f) {
            tintPaint.alpha = (tintAlpha.coerceIn(0f, 1f) * 255).toInt()
            c.drawRect(0f, 0f, w, h, tintPaint)
        }
        if (washAlpha > 0.001f) {
            val a = washPhase * 6.2831855f
            val d = h * 0.6f
            val cx = w / 2f
            val cy = h / 2f
            washPaint.shader = LinearGradient(
                cx - cos(a) * d * 0.5f, cy - sin(a) * d, cx + cos(a) * d * 0.5f, cy + sin(a) * d,
                washColors, null, Shader.TileMode.CLAMP
            )
            washPaint.alpha = (washAlpha.coerceIn(0f, 1f) * 255).toInt()
            c.drawRect(0f, 0f, w, h, washPaint)
        }
        if (rimAlpha > 0.001f) {
            m.setRotate(rimPhase, w / 2f, h / 2f)
            sweep?.setLocalMatrix(m)
            val k = rimAlpha.coerceIn(0f, 1f)
            glowPaint.alpha = (0.85f * k * 255).toInt()
            c.drawPath(path, glowPaint)
            bandPaint.alpha = (k * 255).toInt()
            c.drawPath(path, bandPaint)
        }
    }
}
