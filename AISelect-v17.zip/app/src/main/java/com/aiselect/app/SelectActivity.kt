package com.aiselect.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.WallpaperManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.animation.AnimatorSet
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.window.OnBackInvokedDispatcher
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

class SelectActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var bgImg: ImageView
    private lateinit var rim: RimView
    private lateinit var glow: GlowView
    private lateinit var sparkles: LottieAnimationView
    private lateinit var selection: SelectionView
    private lateinit var chips: LinearLayout
    private lateinit var toolbar: LinearLayout
    private lateinit var textIcon: ImageView
    private lateinit var lottie: LottieAnimationView
    private lateinit var wallChip: LinearLayout
    private lateinit var exBtn: FrameLayout
    private lateinit var exGap: View
    private var detectJob = 0
    private var panelsShown = false
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private lateinit var moreBtn: FrameLayout
    private lateinit var close: CloseButton
    private var closeHidden = false
    private var dragHidden = false
    private var panelAnim: ValueAnimator? = null
    private var rimSpin: ValueAnimator? = null
    private var resultPanel: View? = null
    private var shot: Bitmap? = null
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 34) {
            overrideActivityTransition(OVERRIDE_TRANSITION_OPEN, 0, 0)
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, 0, 0)
        }
        val bmp = ShotHolder.bitmap
        if (bmp == null) {
            finish()
            return
        }
        shot = bmp

        WindowCompat.setDecorFitsSystemWindows(window, false)
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        window.attributes = lp
        // system bars stay visible so Samsung's own back gesture works exactly as everywhere else
        window.isNavigationBarContrastEnforced = false

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        bgImg = ImageView(this)
        bgImg.setImageBitmap(bmp)
        bgImg.scaleType = ImageView.ScaleType.FIT_XY
        root.addView(bgImg, FrameLayout.LayoutParams(match, match))

        rim = RimView(this)
        root.addView(rim, FrameLayout.LayoutParams(match, match))

        glow = GlowView(this)
        root.addView(glow, FrameLayout.LayoutParams(match, match))

        // the white Galaxy AI sparkles from the original Lottie
        sparkles = LottieAnimationView(this)
        sparkles.setAnimation(R.raw.intelligence_affordance)
        sparkles.visibility = View.INVISIBLE
        val sp = ui(155f)
        val spl = FrameLayout.LayoutParams(sp, sp, Gravity.TOP or Gravity.START)
        root.addView(sparkles, spl)

        selection = SelectionView(this)
        root.addView(selection, FrameLayout.LayoutParams(match, match))
        underlines = UnderlineView(this)
        root.addView(underlines, FrameLayout.LayoutParams(match, match))
        root.post { startLinkScan(bmp) }

        buildChips()
        buildToolbar()
        chips.visibility = View.GONE
        toolbar.visibility = View.GONE
        root.addView(chips, FrameLayout.LayoutParams(wrap, ui(96f), Gravity.TOP or Gravity.START))
        root.addView(toolbar, FrameLayout.LayoutParams(wrap, ui(132f), Gravity.TOP or Gravity.START))

        close = CloseButton(this)
        close.alpha = 0f
        close.setOnClickListener { finish() }
        val cl = FrameLayout.LayoutParams(ui(100f), ui(100f), Gravity.TOP or Gravity.END)
        cl.topMargin = ui(140f)
        cl.marginEnd = ui(110f)
        root.addView(close, cl)

        selection.onTouchStart = { onTouchStart() }
        selection.onSelected = { r -> onSelected(r) }
        selection.onCleared = {
            detectJob++
            hidePanels()
        }
        selection.onDragStart = { hidePanelsForDrag() }
        selection.onRectChanged = { r -> if (panelsShown && !dragHidden) layoutPanels(r) }

        setContentView(root)

        onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT) {
            handleBack()
        }

        playEntry()
    }

    private fun u(px: Float) = (this as android.content.Context).u(px)
    private fun ui(px: Float) = (this as android.content.Context).ui(px)

    // ---------- entry animation ----------

    private var entryTarget = 0L
    private var entryPending = false

    private fun playEntry() {
        entryTarget = ShotHolder.entryAt
        ShotHolder.entryAt = 0L
        if (window.decorView.hasWindowFocus()) {
            scheduleEntry()
        } else {
            // the window is see-through now: wait until it is really on screen, otherwise the first
            // part of the burst would play before anyone can see it
            entryPending = true
            root.postDelayed({
                if (entryPending) {
                    entryPending = false
                    scheduleEntry()
                }
            }, 600)
        }
    }

    private fun scheduleEntry() {
        val wait = (entryTarget - SystemClock.uptimeMillis()).coerceAtLeast(0L)
        if (wait > 0L) root.postDelayed({ runEntry() }, wait) else root.postDelayed({ runEntry() }, 30)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && entryPending) {
            entryPending = false
            scheduleEntry()
        }
    }

    /** Timing measured frame by frame from the original recording (t = first frame of the effect). */
    private fun runEntry() {
        if (isDestroyed) return
        entryStartedAt = SystemClock.uptimeMillis()
        showLinksIfReady()
        selection.showIdleDim()
        val ox = ShotHolder.originX
        val oy = ShotHolder.originY
        ShotHolder.originX = -1f
        ShotHolder.originY = -1f
        if (ox >= 0f && oy >= 0f) {
            // the colors splash out from the edge handle and cover the whole screen
            rim.revealCx = ox
            rim.revealCy = oy
            rim.reveal = 0f
            val rv = ObjectAnimator.ofFloat(rim, "reveal", 0f, 1f)
            rv.duration = 220
            rv.interpolator = android.view.animation.DecelerateInterpolator()
            rv.start()
        } else {
            // action app / tile: the colors burst out of a blob a bit left of and below the screen center
            // (taken from the original recording) and cover the whole screen within ~0.12 s
            val dm = root.resources.displayMetrics
            rim.revealCx = dm.widthPixels * 0.45f
            rim.revealCy = dm.heightPixels * 0.53f
            rim.reveal = 0f
            val rv = ObjectAnimator.ofFloat(rim, "reveal", 0f, 1f)
            rv.duration = 150
            rv.interpolator = android.view.animation.DecelerateInterpolator()
            rv.start()
        }
        close.animate().alpha(1f).setStartDelay(40).setDuration(120).start()

        // color wash: full strength after ~100 ms, gone after ~1 s
        val washUp = ObjectAnimator.ofFloat(rim, "washAlpha", 0f, 0.55f)
        washUp.duration = 100
        val washDown = ObjectAnimator.ofFloat(rim, "washAlpha", 0.55f, 0f)
        washDown.duration = 900
        val washSet = AnimatorSet()
        washSet.playSequentially(washUp, washDown)
        washSet.start()
        val tint = ObjectAnimator.ofFloat(rim, "tintAlpha", 0f, 1f)
        tint.duration = 600
        tint.interpolator = android.view.animation.DecelerateInterpolator()
        tint.start()
        val phase = ObjectAnimator.ofFloat(rim, "washPhase", 0f, 0.35f)
        phase.duration = 1700
        phase.start()
        val rimIn = ObjectAnimator.ofFloat(rim, "rimAlpha", 0f, 1f)
        rimIn.duration = 250
        rimIn.start()
        val spin = ValueAnimator.ofFloat(0f, 360f)
        spin.duration = 14000
        spin.repeatCount = ValueAnimator.INFINITE
        spin.interpolator = android.view.animation.LinearInterpolator()
        spin.addUpdateListener { rim.rimPhase = it.animatedValue as Float }
        rimSpin = spin
        spin.start()

        val sp = ui(155f)
        sparkles.translationX = root.resources.displayMetrics.widthPixels * 0.5f - sp / 2f
        sparkles.translationY = root.resources.displayMetrics.heightPixels * 0.5f - sp / 2f
        sparkles.postDelayed({
            sparkles.visibility = View.VISIBLE
            sparkles.playAnimation()
        }, 30)
        sparkles.addAnimatorListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                sparkles.visibility = View.INVISIBLE
            }
        })
    }

    private fun onTouchStart() {
        underlines?.fadeOut()
        rimSpin?.cancel()
        ObjectAnimator.ofFloat(rim, "tintAlpha", rim.tintAlpha, 0f).setDuration(200).start()
        ObjectAnimator.ofFloat(rim, "rimAlpha", rim.rimAlpha, 0f).setDuration(220).start()
        ObjectAnimator.ofFloat(rim, "washAlpha", rim.washAlpha, 0f).setDuration(150).start()
        sparkles.visibility = View.INVISIBLE
        hidePanels()
    }

    private fun hidePanels() {
        panelsShown = false
        dragHidden = false
        resetPanelAnim()
        for (v in listOf<View>(chips, toolbar)) {
            if (v.visibility == View.VISIBLE) {
                v.animate().cancel()
                v.animate().alpha(0f).setDuration(120).withEndAction { v.visibility = View.GONE }.start()
            }
        }
        if (closeHidden) {
            closeHidden = false
            close.animate().alpha(1f).setStartDelay(0).setDuration(150).start()
        }
    }

    /** Touching the square hides the chips and the toolbar (they come back when the finger lets go). */
    private fun hidePanelsForDrag() {
        if (!panelsShown) return
        dragHidden = true
        resetPanelAnim()
        for (v in listOf<View>(chips, toolbar)) {
            if (v.visibility == View.VISIBLE) {
                v.animate().cancel()
                v.animate().alpha(0f).setDuration(100).withEndAction { v.visibility = View.INVISIBLE }.start()
            }
        }
    }

    private fun chipViews(): List<LinearLayout> {
        val out = ArrayList<LinearLayout>()
        for (i in 0 until chips.childCount) {
            val c = chips.getChildAt(i)
            if (c is LinearLayout && c.tag == "chip") out.add(c)
        }
        return out
    }

    private fun resetPanelAnim() {
        panelAnim?.cancel()
        panelAnim = null
        for (c in chipViews()) {
            val lp = c.layoutParams
            if (lp.width > 0) {
                lp.width = ViewGroup.LayoutParams.WRAP_CONTENT
                c.layoutParams = lp
            }
            val label = c.getChildAt(1)
            if (label != null) {
                label.animate().cancel()
                label.alpha = 1f
            }
        }
        moreBtn.animate().cancel()
        moreBtn.alpha = 1f
        toolbar.scaleX = 1f
    }

    /**
     * Same as the original after you let go: the capsules fade in and grow from the icon to full width,
     * then the labels fade in; the toolbar fades in and widens.
     */
    private fun animatePanelsIn() {
        resetPanelAnim()
        chips.animate().cancel()
        toolbar.animate().cancel()
        val views = chipViews()
        val shrunk = moreBtn.visibility != View.VISIBLE
        val finals = views.map { measuredWidth(it).toInt() }
        val collapsed = ui(144f)

        chips.visibility = View.VISIBLE
        chips.alpha = 0f
        chips.animate().alpha(1f).setDuration(200).setStartDelay(66).start()
        toolbar.visibility = View.VISIBLE
        toolbar.alpha = 0f
        toolbar.pivotX = measuredWidth(toolbar) / 2f
        toolbar.scaleX = 0.55f
        toolbar.animate().alpha(1f).scaleX(1f).setDuration(380).setStartDelay(66)
            .setInterpolator(android.view.animation.DecelerateInterpolator()).start()

        if (shrunk) return
        for (c in views) {
            val label = c.getChildAt(1)
            if (label != null) {
                label.alpha = 0f
                label.animate().alpha(1f).setStartDelay(420).setDuration(160).start()
            }
            val lp = c.layoutParams
            lp.width = collapsed
            c.layoutParams = lp
        }
        moreBtn.alpha = 0f
        moreBtn.animate().alpha(1f).setDuration(150).setStartDelay(300).start()
        val va = ValueAnimator.ofFloat(0f, 1f)
        va.duration = 380
        va.startDelay = 66
        va.interpolator = android.view.animation.DecelerateInterpolator()
        va.addUpdateListener {
            val f = it.animatedValue as Float
            for (i in views.indices) {
                val lp = views[i].layoutParams
                lp.width = (collapsed + (finals[i] - collapsed) * f).toInt()
                views[i].layoutParams = lp
            }
        }
        va.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                if (moreBtn.visibility != View.VISIBLE) return
                for (c in views) {
                    val lp = c.layoutParams
                    lp.width = ViewGroup.LayoutParams.WRAP_CONTENT
                    c.layoutParams = lp
                }
            }
        })
        panelAnim = va
        va.start()
    }

    // ---------- UI ----------

    private fun roundBg(color: Int, radius: Float, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = radius
        if (strokePx > 0) g.setStroke(strokePx, strokeColor)
        return g
    }

    private fun chipBg(): GradientDrawable {
        // sampled from the original: purple-gray on the left, blue in the middle, green-gray on the right
        val g = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xEB4B4D61.toInt(), 0xEB3F4F68.toInt(), 0xEB3E4E4A.toInt())
        )
        g.cornerRadius = u(60f)
        g.setStroke(ui(3f), 0xFF556072.toInt())
        return g
    }

    private fun circleBtn(): FrameLayout {
        val f = FrameLayout(this)
        f.background = chipBg()
        f.elevation = u(6f)
        return f
    }

    private fun buildChips() {
        chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.gravity = Gravity.CENTER_VERTICAL

        // Extract text: round button on the left
        exBtn = circleBtn()
        val ex = exBtn
        textIcon = ImageView(this)
        textIcon.setImageResource(R.drawable.ic_text)
        textIcon.imageTintList = ColorStateList.valueOf(0xFFFFFFFF.toInt())
        ex.addView(textIcon, FrameLayout.LayoutParams(ui(62f), ui(62f), Gravity.CENTER))
        lottie = LottieAnimationView(this)
        lottie.setAnimation(R.raw.intelligence_progress_color)
        lottie.repeatCount = LottieDrawable.INFINITE
        lottie.visibility = View.INVISIBLE
        ex.addView(lottie, FrameLayout.LayoutParams(ui(70f), ui(70f), Gravity.CENTER))
        ex.setOnClickListener { extractText() }
        chips.addView(ex, LinearLayout.LayoutParams(ui(96f), ui(96f)))
        exGap = View(this)
        chips.addView(exGap, LinearLayout.LayoutParams(ui(33f), 1))
        ex.visibility = View.GONE
        exGap.visibility = View.GONE
        wallChip = chip(R.drawable.ic_wallpaper, "Set as wallpaper") { chooseWallpaper() }
        chips.addView(wallChip)
        chips.addView(View(this), LinearLayout.LayoutParams(ui(33f), 1))
        chips.addView(chip(R.drawable.ic_gif, "Create GIF") { createGif() })
        chips.addView(View(this), LinearLayout.LayoutParams(ui(33f), 1))

        // more (three dots) on the right
        moreBtn = circleBtn()
        val dots = DotsView(this)
        moreBtn.addView(dots, FrameLayout.LayoutParams(ui(96f), ui(96f)))
        moreBtn.setOnClickListener { showMenu(moreBtn) }
        chips.addView(moreBtn, LinearLayout.LayoutParams(ui(96f), ui(96f)))
    }

    private fun chip(icon: Int, label: String, onClick: () -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER_VERTICAL
        c.setPadding(ui(40f), 0, ui(46f), 0)
        c.background = chipBg()
        c.tag = "chip"
        c.elevation = u(6f)
        val iv = ImageView(this)
        iv.setImageResource(icon)
        iv.imageTintList = ColorStateList.valueOf(0xFFFFFFFF.toInt())
        c.addView(iv, LinearLayout.LayoutParams(ui(58f), ui(58f)))
        val t = TextView(this)
        t.text = label
        t.setTextColor(0xFFFFFFFF.toInt())
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(37f))
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        val tl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tl.marginStart = ui(18f)
        c.addView(t, tl)
        c.setOnClickListener { onClick() }
        c.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ui(96f))
        return c
    }

    private fun buildToolbar() {
        toolbar = LinearLayout(this)
        toolbar.orientation = LinearLayout.HORIZONTAL
        toolbar.gravity = Gravity.CENTER_VERTICAL
        toolbar.setPadding(ui(22f), ui(18f), ui(22f), ui(18f))
        toolbar.elevation = u(8f)
        val tbBg = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xE633393D.toInt(), 0xE63B4C53.toInt(), 0xE6435256.toInt(), 0xE6405050.toInt(), 0xE6434F48.toInt())
        )
        tbBg.cornerRadius = u(70f)
        toolbar.background = tbBg
        val icons = listOf(R.drawable.ic_edit, R.drawable.ic_pin, R.drawable.ic_copy, R.drawable.ic_share, R.drawable.ic_save)
        val acts = listOf<() -> Unit>({ doEdit() }, { doPin() }, { doCopy() }, { doShare() }, { doSave() })
        for (i in icons.indices) {
            val b = ImageView(this)
            b.setImageResource(icons[i])
            b.imageTintList = ColorStateList.valueOf(0xFFFFFFFF.toInt())
            b.scaleType = ImageView.ScaleType.FIT_CENTER
            b.setPadding(ui(12f), ui(12f), ui(12f), ui(12f))
            b.background = roundBg(0xFF313236.toInt(), u(60f))
            b.setOnClickListener { acts[i]() }
            val bl = LinearLayout.LayoutParams(ui(96f), ui(96f))
            if (i > 0) bl.marginStart = ui(49f)
            toolbar.addView(b, bl)
        }
    }

    private fun showMenu(anchor: View) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xF24B4D61.toInt(), 0xF23F4F68.toInt(), 0xF23E4E4A.toInt())
        )
        bg.cornerRadius = u(36f)
        bg.setStroke(ui(2f), 0xFF556072.toInt())
        box.background = bg
        box.elevation = u(14f)
        box.setPadding(0, ui(14f), 0, ui(14f))
        val pw = android.widget.PopupWindow(box, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.isOutsideTouchable = true
        pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0))
        fun item(text: String, onClick: () -> Unit) {
            val t = TextView(this)
            t.text = text
            t.setTextColor(0xFFFFFFFF.toInt())
            t.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(46f))
            t.gravity = Gravity.CENTER_VERTICAL
            t.minWidth = ui(560f)
            t.setPadding(ui(52f), 0, ui(52f), 0)
            t.setOnClickListener {
                pw.dismiss()
                onClick()
            }
            box.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ui(150f)))
        }
        item("Accessibility settings") { startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        item("App info") {
            startActivity(
                Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }
        item("Close") { finish() }
        pw.showAsDropDown(anchor, 0, 0, Gravity.END)
    }

    /** Positions the chip row and toolbar under/over the square; they follow it while it is moved. */
    private fun layoutPanels(r: RectF) {
        val w = root.width.toFloat()
        val h = root.height.toFloat()
        val chipH = u(96f)
        val tbW = measuredWidth(toolbar)
        val tbH = u(132f)

        // chip row: shrink "Set as wallpaper" and drop the dots when the row is too wide (as in the original)
        val maxW = w - u(80f)
        moreBtn.visibility = View.VISIBLE
        for (c in chipViews()) {
            val clp = c.layoutParams
            if (clp.width > 0) {
                clp.width = ViewGroup.LayoutParams.WRAP_CONTENT
                c.layoutParams = clp
            }
        }
        wallChip.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ui(96f))
        val lp0 = chips.layoutParams
        lp0.width = ViewGroup.LayoutParams.WRAP_CONTENT
        chips.layoutParams = lp0
        var chipW = measuredWidth(chips)
        if (chipW > maxW) {
            moreBtn.visibility = View.GONE
            panelAnim?.cancel()
            wallChip.layoutParams = LinearLayout.LayoutParams(0, ui(96f), 1f)
            val lp = chips.layoutParams
            lp.width = maxW.toInt()
            chips.layoutParams = lp
            chipW = maxW
        }

        val chipsAbove = r.top - u(38f) - chipH >= u(120f)
        val chipTop = if (chipsAbove) r.top - u(38f) - chipH else minOf(r.bottom + u(38f), h - u(420f))
        var tbTop = if (chipsAbove) r.bottom + u(60f) else chipTop + chipH + u(65f)
        tbTop = minOf(tbTop, h - u(110f) - tbH)

        val cx = r.centerX()
        place(chips, (cx - chipW / 2f).coerceIn(u(40f), maxOf(u(40f), w - chipW - u(30f))), chipTop)
        place(toolbar, (cx - tbW / 2f).coerceIn(u(45f), maxOf(u(45f), w - tbW - u(45f))), tbTop)
    }

    private fun onSelected(r: RectF) {
        val firstTime = !panelsShown
        panelsShown = true
        layoutPanels(r)
        detectText()

        // the X goes away once something is selected (as in the original)
        closeHidden = true
        close.animate().alpha(0f).setDuration(150).start()

        if (firstTime || dragHidden) {
            dragHidden = false
            animatePanelsIn()
        }
    }

    /** The round "Extract text" button only appears when there is text inside the square. */
    private fun detectText() {
        val crop = currentCrop() ?: return
        val id = ++detectJob
        recognizer.process(InputImage.fromBitmap(crop, 0))
            .addOnSuccessListener { r -> if (id == detectJob) setTextButton(r.text.isNotBlank()) }
            .addOnFailureListener { if (id == detectJob) setTextButton(false) }
    }

    private fun setTextButton(show: Boolean) {
        val vis = if (show) View.VISIBLE else View.GONE
        if (exBtn.visibility == vis) return
        exBtn.visibility = vis
        exGap.visibility = vis
        if (panelsShown) layoutPanels(selection.selectedRect())
    }

    private fun measuredWidth(v: View): Float {
        v.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        return v.measuredWidth.toFloat()
    }

    private fun place(v: View, x: Float, y: Float) {
        v.translationX = x
        v.translationY = y
    }

    // ---------- actions ----------

    private fun currentCrop(): Bitmap? {
        val s = shot ?: return null
        return selection.crop(s)
    }

    private fun cacheUri(bmp: Bitmap): Uri {
        val dir = File(cacheDir, "shared")
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }
        val f = File(dir, "aiselect_${System.currentTimeMillis()}.png")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return FileProvider.getUriForFile(this, "$packageName.files", f)
    }

    private fun doEdit() {
        val bmp = currentCrop() ?: return
        val uri = cacheUri(bmp)
        val i = Intent(Intent.ACTION_EDIT)
        i.setDataAndType(uri, "image/png")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "No editor found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun doPin() {
        val bmp = currentCrop() ?: return
        val r = selection.selectedRect()
        val svc = AISelectService.instance
        if (svc != null) {
            val sx = shot!!.width / root.width.toFloat()
            val sy = shot!!.height / root.height.toFloat()
            svc.pin(bmp, (r.left * sx).toInt(), (r.top * sy).toInt())
        }
        finish()
    }

    private fun doCopy() {
        val bmp = currentCrop() ?: return
        val uri = cacheUri(bmp)
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newUri(contentResolver, "AI Select", uri))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun doSave() {
        val bmp = currentCrop() ?: return
        val o = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, o)
        val ok = saveToPictures(this, "AISelect_${System.currentTimeMillis()}.png", "image/png", o.toByteArray())
        Toast.makeText(this, if (ok) "Saved to Pictures/AI Select" else "Couldn't save", Toast.LENGTH_SHORT).show()
        if (ok) finish()
    }

    private fun doShare() {
        val bmp = currentCrop() ?: return
        val uri = cacheUri(bmp)
        val i = Intent(Intent.ACTION_SEND)
        i.type = "image/png"
        i.putExtra(Intent.EXTRA_STREAM, uri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, null))
    }

    /** "Choose where to apply" bottom sheet, like the original: Lock / Home previews with check marks and Next. */
    private fun chooseWallpaper() {
        val bmp = currentCrop() ?: return
        hideResult()
        val panel = FrameLayout(this)
        panel.setBackgroundColor(0x99000000.toInt())
        panel.elevation = u(80f)
        panel.outlineProvider = null
        panel.setOnClickListener { hideResult() }

        val sheet = LinearLayout(this)
        sheet.orientation = LinearLayout.VERTICAL
        sheet.isClickable = true
        sheet.elevation = u(20f)
        sheet.background = roundBg(0xFF3A3A3C.toInt(), u(80f))
        sheet.setPadding(ui(70f), ui(70f), ui(70f), ui(30f))

        val title = TextView(this)
        title.text = "Choose where to apply"
        title.setTextColor(0xFFFFFFFF.toInt())
        title.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(60f))
        title.typeface = Typeface.DEFAULT_BOLD
        sheet.addView(title)

        var lock = true
        var home = true
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_HORIZONTAL
        val next = TextView(this)

        fun refreshNext() {
            next.alpha = if (lock || home) 1f else 0.35f
        }

        fun column(name: String, isLock: Boolean): LinearLayout {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            val card = ImageView(this)
            card.setImageBitmap(bmp)
            card.scaleType = ImageView.ScaleType.CENTER_CROP
            card.background = roundBg(0xFF1C1C1E.toInt(), u(46f))
            card.clipToOutline = true
            col.addView(card, LinearLayout.LayoutParams(ui(280f), ui(606f)))
            val label = TextView(this)
            label.text = name
            label.setTextColor(0xFFFFFFFF.toInt())
            label.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(54f))
            val llp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            llp.topMargin = ui(26f)
            col.addView(label, llp)
            val check = TextView(this)
            check.gravity = Gravity.CENTER
            check.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(40f))
            check.setTextColor(0xFFFFFFFF.toInt())
            fun paint() {
                val on = if (isLock) lock else home
                check.text = if (on) "\u2713" else ""
                check.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    if (on) setColor(0xFF3E6EFF.toInt()) else setColor(0x00000000)
                    setStroke(ui(4f), if (on) 0xFF3E6EFF.toInt() else 0xFF8E8E93.toInt())
                }
            }
            paint()
            val clp = LinearLayout.LayoutParams(ui(66f), ui(66f))
            clp.topMargin = ui(26f)
            col.addView(check, clp)
            col.setOnClickListener {
                if (isLock) lock = !lock else home = !home
                paint()
                refreshNext()
            }
            return col
        }
        val c1 = column("Lock screen", true)
        val c2 = column("Home screen", false)
        row.addView(c1, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val gap = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        gap.marginStart = ui(136f)
        row.addView(c2, gap)
        val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rlp.topMargin = ui(44f)
        sheet.addView(row, rlp)

        next.text = "Next"
        next.gravity = Gravity.CENTER
        next.setTextColor(0xFFFFFFFF.toInt())
        next.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(64f))
        next.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        next.setPadding(0, ui(60f), 0, ui(60f))
        next.setOnClickListener {
            if (!lock && !home) return@setOnClickListener
            var flags = 0
            if (home) flags = flags or WallpaperManager.FLAG_SYSTEM
            if (lock) flags = flags or WallpaperManager.FLAG_LOCK
            val f = flags
            Thread {
                try {
                    WallpaperManager.getInstance(this).setBitmap(bmp, null, true, f)
                    runOnUiThread {
                        Toast.makeText(this, "Wallpaper set", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this, "Couldn't set wallpaper", Toast.LENGTH_SHORT).show() }
                }
            }.start()
        }
        sheet.addView(next, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val slp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        slp.leftMargin = ui(30f)
        slp.rightMargin = ui(30f)
        slp.bottomMargin = ui(30f)
        panel.addView(sheet, slp)
        panel.alpha = 0f
        root.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        resultPanel = panel
        panel.animate().alpha(1f).setDuration(160).start()
        sheet.translationY = ui(200f).toFloat()
        sheet.animate().translationY(0f).setDuration(220)
            .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
    }

    private fun createGif() {
        val r = selection.selectedRect()
        val sx = shot!!.width / root.width.toFloat()
        val sy = shot!!.height / root.height.toFloat()
        val region = Rect((r.left * sx).toInt(), (r.top * sy).toInt(), (r.right * sx).toInt(), (r.bottom * sy).toInt())
        AISelectService.instance?.startGif(region)
        finish()
    }

    // ---------- Text selection (like the original) ----------

    private var textMode = false
    private var textView: TextSelectView? = null
    private var textCircle: View? = null
    private var textBar: View? = null
    private var textOrigRect = RectF()
    private var textFrame = RectF()

    private fun extractText() {
        if (busy) return
        val crop = currentCrop() ?: return
        val r = selection.selectedRect()
        busy = true
        textIcon.visibility = View.INVISIBLE
        lottie.visibility = View.VISIBLE
        lottie.playAnimation()
        glow.start()
        recognizer.process(InputImage.fromBitmap(crop, 0))
            .addOnSuccessListener { res ->
                endOcr()
                enterTextMode(res, crop.width, crop.height, r)
            }
            .addOnFailureListener {
                endOcr()
                Toast.makeText(this, "No text found", Toast.LENGTH_SHORT).show()
            }
    }

    private fun endOcr() {
        busy = false
        lottie.cancelAnimation()
        lottie.visibility = View.INVISIBLE
        textIcon.visibility = View.VISIBLE
        glow.stop()
    }

    private fun enterTextMode(res: com.google.mlkit.vision.text.Text, cw: Int, ch: Int, r: RectF) {
        val kx = r.width() / cw
        val ky = r.height() / ch
        val chars = ArrayList<TextSelectView.Ch>()
        var line = 0
        var word = 0
        for (b in res.textBlocks) {
            for (l in b.lines) {
                for (el in l.elements) {
                    val eb = el.boundingBox ?: continue
                    val text = el.text
                    if (text.isEmpty()) continue
                    val syms = symbolsOf(el)
                    var usedSymbols = false
                    if (syms.isNotEmpty() && syms.size == text.length) {
                        val tmp = ArrayList<TextSelectView.Ch>()
                        var ok = true
                        for (sy in syms) {
                            val sb = sy.second
                            if (sb == null) {
                                ok = false
                                break
                            }
                            tmp.add(
                                TextSelectView.Ch(
                                    sy.first,
                                    RectF(r.left + sb.left * kx, r.top + sb.top * ky, r.left + sb.right * kx, r.top + sb.bottom * ky),
                                    line,
                                    word
                                )
                            )
                        }
                        if (ok) {
                            chars.addAll(tmp)
                            usedSymbols = true
                        }
                    }
                    if (!usedSymbols) {
                        // no per-letter boxes: split the word box evenly
                        val n = text.length
                        val wl = r.left + eb.left * kx
                        val wr = r.left + eb.right * kx
                        val wt = r.top + eb.top * ky
                        val wb = r.top + eb.bottom * ky
                        for (k in 0 until n) {
                            val x1 = wl + (wr - wl) * k / n
                            val x2 = wl + (wr - wl) * (k + 1) / n
                            chars.add(TextSelectView.Ch(text.substring(k, k + 1), RectF(x1, wt, x2, wb), line, word))
                        }
                    }
                    word++
                }
                line++
            }
        }
        if (chars.isEmpty()) {
            Toast.makeText(this, "No text found", Toast.LENGTH_SHORT).show()
            return
        }
        textMode = true
        for (v in listOf<View>(chips, toolbar)) {
            v.animate().cancel()
            v.animate().alpha(0f).setDuration(120).withEndAction { v.visibility = View.INVISIBLE }.start()
        }
        selection.setArcsVisible(false)
        underlines?.fadeOut()
        textOrigRect = RectF(r)
        textFrame = RectF(r)

        val tv = TextSelectView(this)
        tv.chars = chars
        tv.onDragStart = {
            for (v in listOf<View?>(textCircle, textBar)) v?.animate()?.alpha(0f)?.setDuration(100)?.start()
        }
        tv.onBounds = { bnd ->
            // the frame hugs the selected letters and follows the handle while it is dragged
            val m = u(26f)
            val t = RectF(bnd.left - m, bnd.top - m, bnd.right + m, bnd.bottom + m)
            textFrame = t
            selection.animateRectTo(t, 110)
        }
        tv.onDragEnd = {
            placeTextTools()
            for (v in listOf<View?>(textCircle, textBar)) v?.animate()?.alpha(1f)?.setDuration(160)?.setStartDelay(80)?.start()
        }
        root.addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        textView = tv

        // round "T" button above the square: tap it to leave text mode
        val circle = FrameLayout(this)
        circle.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF4B9FB0.toInt(), 0xFF5CB28C.toInt())
        ).apply { shape = GradientDrawable.OVAL }
        circle.elevation = u(8f)
        val ti = ImageView(this)
        ti.setImageResource(R.drawable.ic_text)
        ti.imageTintList = ColorStateList.valueOf(0xFFFFFFFF.toInt())
        circle.addView(ti, FrameLayout.LayoutParams(ui(62f), ui(62f), Gravity.CENTER))
        circle.setOnClickListener { exitTextMode() }
        val cs = ui(100f)
        root.addView(circle, FrameLayout.LayoutParams(cs, cs))
        textCircle = circle

        // small toolbar under the square: pin, copy, share
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(ui(22f), ui(18f), ui(22f), ui(18f))
        bar.background = roundBg(0xF0303034.toInt(), u(70f))
        bar.elevation = u(8f)
        fun btn(res: Int, action: () -> Unit) {
            val f = FrameLayout(this)
            f.background = roundBg(0xFF262628.toInt(), u(60f))
            val iv = ImageView(this)
            iv.setImageResource(res)
            iv.imageTintList = ColorStateList.valueOf(0xFFFFFFFF.toInt())
            f.addView(iv, FrameLayout.LayoutParams(ui(50f), ui(50f), Gravity.CENTER))
            f.setOnClickListener { action() }
            val lp = LinearLayout.LayoutParams(ui(96f), ui(96f))
            lp.marginStart = ui(10f)
            lp.marginEnd = ui(10f)
            bar.addView(f, lp)
        }
        btn(R.drawable.ic_pin) { doPin() }
        btn(R.drawable.ic_copy) {
            val t = tv.selectedText()
            if (t.isNotEmpty()) {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("AI Select", t))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            }
        }
        btn(R.drawable.ic_share) {
            val t = tv.selectedText()
            if (t.isNotEmpty()) {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "text/plain"
                i.putExtra(Intent.EXTRA_TEXT, t)
                startActivity(Intent.createChooser(i, null))
            }
        }
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        textBar = bar
        placeTextTools()
        for (v in listOf<View>(circle, bar, tv)) {
            v.alpha = 0f
            v.animate().alpha(1f).setDuration(160).start()
        }
    }

    /** Per-letter boxes from the recognizer; empty when the library does not provide them (then the word box is split evenly). */
    private fun symbolsOf(el: Any): List<Pair<String, android.graphics.Rect?>> {
        return try {
            val list = el.javaClass.getMethod("getSymbols").invoke(el) as? List<*> ?: return emptyList()
            val out = ArrayList<Pair<String, android.graphics.Rect?>>()
            for (sy in list) {
                if (sy == null) continue
                val t = sy.javaClass.getMethod("getText").invoke(sy) as? String ?: continue
                val b = sy.javaClass.getMethod("getBoundingBox").invoke(sy) as? android.graphics.Rect
                out.add(Pair(t, b))
            }
            out
        } catch (e: Throwable) {
            emptyList()
        }
    }

    /** Round T button above the frame and the small bar under it follow the current frame. */
    private fun placeTextTools() {
        val c = textCircle ?: return
        val b = textBar ?: return
        val f = textFrame
        val cs = ui(100f)
        c.translationX = f.centerX() - cs / 2f
        c.translationY = (f.top - ui(88f) - cs / 2f).coerceAtLeast(ui(110f).toFloat())
        val bw = measuredWidth(b)
        b.translationX = f.centerX() - bw / 2f
        b.translationY = (f.bottom + ui(58f)).coerceAtMost(root.height - ui(200f).toFloat())
    }

    private fun exitTextMode() {
        if (!textMode) return
        textMode = false
        selection.animateRectTo(textOrigRect, 160)
        textView?.let { root.removeView(it) }
        textCircle?.let { root.removeView(it) }
        textBar?.let { root.removeView(it) }
        textView = null
        textCircle = null
        textBar = null
        selection.setArcsVisible(true)
        for (v in listOf<View>(chips, toolbar)) {
            v.animate().cancel()
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(150).start()
        }
    }

    // ---------- gradient line under links and numbers ----------

    private var underlines: UnderlineView? = null
    private var linkBoxes: List<RectF>? = null
    private var linksShown = false
    private var entryStartedAt = 0L
    private val tld = "(com|net|org|me|io|co|ir|info|app|dev|ai|tv|ly|gg|us|uk|de|fr|ru|biz|xyz|edu|gov|link|page|site|online|store)"
    private val urlRe = Regex("^(https?://\\S+|www\\.\\S+|[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*\\.$tld(/\\S*)?)$", RegexOption.IGNORE_CASE)
    private val mailRe = Regex("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$")
    private val countRe = Regex("^[$\\u20AC\\u00A3]?\\d+([.,]\\d+)?[KkMmBb]$")
    private val moneyRe = Regex("^[$\\u20AC\\u00A3]\\d[\\d.,]*$")
    private val phoneRe = Regex("^\\+?\\(?\\d[\\d().-]{5,}\\d$")

    private fun isLinkOrNumber(raw: String): Boolean {
        val t = raw.trim().trim(',', ';', ':', '"', '\'', '(', ')', '[', ']')
        if (t.length < 3) return false
        return urlRe.matches(t) || mailRe.matches(t) || countRe.matches(t) || moneyRe.matches(t) || phoneRe.matches(t)
    }

    private fun startLinkScan(bmp: Bitmap) {
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { res ->
                val sx = root.width / bmp.width.toFloat()
                val sy = root.height / bmp.height.toFloat()
                val out = ArrayList<RectF>()
                for (b in res.textBlocks) for (l in b.lines) for (el in l.elements) {
                    if (!isLinkOrNumber(el.text)) continue
                    val bb = el.boundingBox ?: continue
                    out.add(RectF(bb.left * sx, bb.top * sy, bb.right * sx, bb.bottom * sy))
                }
                linkBoxes = out
                showLinksIfReady()
            }
    }

    /** In the original the lines draw in about a second after the effect starts. */
    private fun showLinksIfReady() {
        val boxes = linkBoxes ?: return
        if (linksShown || entryStartedAt == 0L || boxes.isEmpty()) return
        linksShown = true
        val wait = (entryStartedAt + 1000L - SystemClock.uptimeMillis()).coerceAtLeast(0L)
        root.postDelayed({
            if (isDestroyed || textMode) return@postDelayed
            underlines?.boxes = boxes
            underlines?.animateIn()
        }, wait)
    }

    private fun showResult(text: String) {
        hideResult()
        val empty = text.isEmpty()
        val panel = FrameLayout(this)
        panel.setBackgroundColor(0x33000000)
        panel.elevation = u(80f)
        panel.outlineProvider = null
        panel.setOnClickListener { hideResult() }

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(ui(64f), ui(64f), ui(64f), ui(40f))
        card.elevation = u(20f)
        card.isClickable = true
        card.background = roundBg(0xFFFCFCFC.toInt(), u(70f))

        val title = TextView(this)
        title.text = "Text"
        title.setTextColor(0xFF010101.toInt())
        title.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(44f))
        title.typeface = Typeface.DEFAULT_BOLD
        card.addView(title)

        val body = TextView(this)
        body.text = if (empty) "No text found in the selection" else text
        body.setTextColor(if (empty) 0xFF848487.toInt() else 0xFF505050.toInt())
        body.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(38f))
        body.setLineSpacing(u(10f), 1f)
        body.setTextIsSelectable(!empty)
        val scroll = ScrollView(this)
        scroll.addView(body)
        val sl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        sl.topMargin = ui(40f)
        sl.bottomMargin = ui(28f)
        card.addView(scroll, sl)
        body.viewTreeObserver.addOnGlobalLayoutListener {
            val maxH = ui(560f)
            if (scroll.height > maxH) {
                val p = scroll.layoutParams
                p.height = maxH
                scroll.layoutParams = p
            }
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.END
        if (!empty) {
            row.addView(textButton("Copy") {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("AI Select", text))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            })
            row.addView(textButton("Share") {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "text/plain"
                i.putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(i, null))
            })
        }
        row.addView(textButton("Close") { hideResult() })
        card.addView(row)

        val cl = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        cl.marginStart = ui(32f)
        cl.marginEnd = ui(32f)
        cl.bottomMargin = ui(60f)
        panel.addView(card, cl)

        root.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        resultPanel = panel
        card.translationY = ui(1200f).toFloat()
        val sa = SpringAnimation(card, DynamicAnimation.TRANSLATION_Y, 0f)
        sa.spring.setStiffness(SpringForce.STIFFNESS_LOW)
        sa.spring.setDampingRatio(SpringForce.DAMPING_RATIO_LOW_BOUNCY)
        sa.start()
    }

    private fun textButton(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(0xFF010101.toInt())
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(42f))
        t.setPadding(ui(36f), ui(22f), ui(36f), ui(22f))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun hideResult() {
        resultPanel?.let { root.removeView(it) }
        resultPanel = null
    }

    override fun finish() {
        super.finish()
        // the original just cuts to the home screen: no shrinking card, no fade
        if (android.os.Build.VERSION.SDK_INT >= 34) {
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, 0, 0)
        } else {
            @Suppress("DEPRECATION")
            overridePendingTransition(0, 0)
        }
    }

    private fun handleBack() {
        if (textMode) exitTextMode() else if (resultPanel != null) hideResult() else finish()
    }

    override fun onDestroy() {
        rimSpin?.cancel()
        if (isFinishing) ShotHolder.bitmap = null
        AISelectService.instance?.setEdgeShown(true)
        super.onDestroy()
    }
}
