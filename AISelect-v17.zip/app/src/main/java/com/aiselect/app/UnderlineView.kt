package com.aiselect.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.animation.DecelerateInterpolator

/** The gradient line the original draws under links, e-mails, phone numbers and counts like 17.2K. */
class UnderlineView(context: Context) : android.view.View(context) {
    var boxes: List<RectF> = emptyList()
    private var p = 0f
    private var a = 1f
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = context.u(5f)
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = context.u(9f)
        maskFilter = BlurMaskFilter(context.u(8f), BlurMaskFilter.Blur.NORMAL)
    }

    fun animateIn() {
        val v = ValueAnimator.ofFloat(0f, 1f)
        v.duration = 380
        v.interpolator = DecelerateInterpolator()
        v.addUpdateListener {
            p = it.animatedValue as Float
            invalidate()
        }
        v.start()
    }

    fun fadeOut() {
        animate().alpha(0f).setDuration(150).start()
    }

    override fun onDraw(c: Canvas) {
        if (p <= 0f) return
        for (b in boxes) {
            val y = b.bottom + context.u(2f)
            val x1 = b.left
            val x2 = b.left + (b.right - b.left) * p
            val g = LinearGradient(b.left, y, b.right, y, 0xFF2BB5EE.toInt(), 0xFF2FD9A2.toInt(), Shader.TileMode.CLAMP)
            glow.shader = g
            glow.alpha = (0.55f * 255).toInt()
            c.drawLine(x1, y, x2, y, glow)
            line.shader = g
            c.drawLine(x1, y, x2, y, line)
        }
    }
}
