package com.aiselect.app

import android.graphics.Bitmap

/** Holds the last screenshot in memory (too big to pass through an Intent). */
object ShotHolder {
    @Volatile
    var bitmap: Bitmap? = null

    /** uptimeMillis at which the entry effect should start (0 = right away). */
    @Volatile
    var entryAt: Long = 0L

    /** Screen point the color splash spreads from (-1 = whole screen at once). */
    @Volatile
    var originX: Float = -1f

    @Volatile
    var originY: Float = -1f
}
