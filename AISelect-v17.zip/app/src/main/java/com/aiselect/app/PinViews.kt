package com.aiselect.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Shader
import android.view.View
import kotlin.math.max

/** The pinned picture when it is minimized: a small circle with the picture inside and a dark ring. */
class PinCircle(context: Context, private val bmp: Bitmap) : View(context) {
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFF3A3A3C.toInt()
        strokeWidth = context.u(12f)
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shader = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)

    override fun onDraw(c: Canvas) {
        val d = width.toFloat()
        val m = Matrix()
        val k = max(d / bmp.width, d / bmp.height)
        m.setScale(k, k)
        m.postTranslate((d - bmp.width * k) / 2f, (d - bmp.height * k) / 2f)
        shader.setLocalMatrix(m)
        fill.shader = shader
        val r = d / 2f
        c.drawCircle(r, r, r - ring.strokeWidth / 2f, fill)
        c.drawCircle(r, r, r - ring.strokeWidth / 2f, ring)
    }
}
