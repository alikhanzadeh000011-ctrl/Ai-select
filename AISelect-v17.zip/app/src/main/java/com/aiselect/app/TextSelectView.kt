package com.aiselect.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * Text selection like the original: the recognised text is highlighted, teardrop handles sit under the
 * first and the last selected character and can be dragged letter by letter. While a handle is dragged a
 * gradient rounded frame follows the selected text.
 */
class TextSelectView(context: Context) : View(context) {

    /** One recognised character (box in screen coordinates), [word] = index of the word it belongs to. */
    class Ch(val t: String, val box: RectF, val line: Int, val word: Int)

    var chars: List<Ch> = emptyList()
        set(v) {
            field = v
            start = 0
            end = v.size - 1
            invalidate()
        }
    var start = 0
    var end = -1

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xA67FB2D6.toInt() }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = context.u(5f)
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = context.u(14f)
        maskFilter = BlurMaskFilter(context.u(18f), BlurMaskFilter.Blur.NORMAL)
    }
    private val r = context.u(32f)
    private val pad = context.u(4f)
    private var drag = 0
    private val path = Path()
    private val rect = RectF()
    private val union = RectF()
    var onDragStart: (() -> Unit)? = null
    var onBounds: ((RectF) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null

    fun selectedText(): String {
        if (chars.isEmpty() || end < start) return ""
        val sb = StringBuilder()
        var prev: Ch? = null
        for (i in start..end) {
            val c = chars[i]
            if (prev != null && prev.word != c.word) sb.append(if (c.line != prev.line) "\n" else " ")
            sb.append(c.t)
            prev = c
        }
        return sb.toString()
    }

    /** Bounding box of the selected letters (screen coordinates). */
    fun selectionBounds(): RectF {
        val b = RectF(chars[start].box)
        for (i in start + 1..end) b.union(chars[i].box)
        return b
    }

    private fun handleRect(i: Int, isStart: Boolean): RectF {
        val b = chars[i].box
        return if (isStart) RectF(b.left - 2 * r, b.bottom, b.left, b.bottom + 2 * r)
        else RectF(b.right, b.bottom, b.right + 2 * r, b.bottom + 2 * r)
    }

    private fun drawHandle(c: Canvas, i: Int, isStart: Boolean) {
        val h = handleRect(i, isStart)
        handlePaint.shader = LinearGradient(h.left, h.top, h.left, h.bottom, 0xFF7FC4F0.toInt(), 0xFF8FE3BD.toInt(), Shader.TileMode.CLAMP)
        path.reset()
        val radii = if (isStart) floatArrayOf(r, r, 0f, 0f, r, r, r, r) else floatArrayOf(0f, 0f, r, r, r, r, r, r)
        path.addRoundRect(h, radii, Path.Direction.CW)
        c.drawPath(path, handlePaint)
    }

    override fun onDraw(c: Canvas) {
        if (chars.isEmpty() || end < start) return
        // highlight: one box per word (the selected part of it)
        var i = start
        var first = true
        while (i <= end) {
            val w = chars[i].word
            var j = i
            rect.set(chars[i].box)
            while (j + 1 <= end && chars[j + 1].word == w) {
                j++
                rect.union(chars[j].box)
            }
            c.drawRoundRect(rect.left - pad, rect.top - pad, rect.right + pad, rect.bottom + pad, pad * 1.5f, pad * 1.5f, fill)
            if (first) {
                union.set(rect)
                first = false
            } else {
                union.union(rect)
            }
            i = j + 1
        }

        drawHandle(c, start, true)
        drawHandle(c, end, false)
    }

    private fun nearest(x: Float, y: Float): Int {
        var best = 0
        var bestD = Float.MAX_VALUE
        for (i in chars.indices) {
            val b = chars[i].box
            val dx = max(max(b.left - x, 0f), x - b.right)
            val dy = max(max(b.top - y, 0f), y - b.bottom)
            val d = dx * dx + dy * dy
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        return best
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                drag = 0
                if (chars.isNotEmpty() && end >= start) {
                    val hs = handleRect(start, true)
                    val he = handleRect(end, false)
                    val m = r * 0.7f
                    if (e.x >= hs.left - m && e.x <= hs.right + m && e.y >= hs.top - m && e.y <= hs.bottom + m) drag = 1
                    else if (e.x >= he.left - m && e.x <= he.right + m && e.y >= he.top - m && e.y <= he.bottom + m) drag = 2
                    if (drag != 0) {
                        onDragStart?.invoke()
                        onBounds?.invoke(selectionBounds())
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (drag != 0) {
                    val idx = nearest(e.x, e.y - r * 1.5f)
                    val ns = if (drag == 1) min(idx, end) else start
                    val ne = if (drag == 2) max(idx, start) else end
                    if (ns != start || ne != end) {
                        start = ns
                        end = ne
                        invalidate()
                        onBounds?.invoke(selectionBounds())
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (drag != 0) onDragEnd?.invoke()
                drag = 0
            }
        }
        return true
    }
}
