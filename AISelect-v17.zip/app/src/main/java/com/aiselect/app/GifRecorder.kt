package com.aiselect.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.max

/**
 * "Create GIF": shows the region frame and a Record pill over the live screen, grabs about
 * 3 frames per second (Android limits screenshots to one per ~330ms) and encodes a GIF.
 */
class GifRecorder(private val svc: AISelectService, private val region: Rect) {

    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val frames = ArrayList<ByteArray>()
    private var fw = 0
    private var fh = 0
    private var frameView: View? = null
    private var pill: LinearLayout? = null
    private var label: TextView? = null
    private var quality: TextView? = null
    private var recording = false
    private var high = true
    private var startMs = 0L
    private var lastShot = 0L

    private fun u(px: Float) = svc.u(px)

    private fun params(w: Int, h: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        return lp
    }

    private var overlay: Overlay? = null
    private var handleWin: View? = null
    private var pillLp: WindowManager.LayoutParams? = null
    private var handleLp: WindowManager.LayoutParams? = null
    private var screenW = 0
    private var screenH = 0

    /** Dim screen with a clear hole, white frame, corner brackets and the move handle (all outside or on the edge of the region). */
    private inner class Overlay : View(svc) {
        var showScrim = true
        var showHandle = true
        var dragging = false
        private val scrim = Paint().apply { color = 0x554E4E4F }
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFFFFFFF.toInt()
            strokeWidth = u(3f)
        }
        private val br = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFFCFCFE.toInt()
            strokeWidth = u(8f)
        }
        private val hp = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = android.graphics.Path()

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val l = region.left.toFloat()
            val t = region.top.toFloat()
            val r = region.right.toFloat()
            val b = region.bottom.toFloat()
            if (showScrim) {
                c.drawRect(0f, 0f, w, t, scrim)
                c.drawRect(0f, b, w, h, scrim)
                c.drawRect(0f, t, l, b, scrim)
                c.drawRect(r, t, w, b, scrim)
            }
            val o1 = line.strokeWidth / 2f
            c.drawRect(l - o1, t - o1, r + o1, b + o1, line)
            val o2 = br.strokeWidth / 2f
            val len = u(60f)
            val L = l - o2
            val T = t - o2
            val R = r + o2
            val B = b + o2
            path.reset()
            path.moveTo(L, T + len); path.lineTo(L, T); path.lineTo(L + len, T)
            path.moveTo(R - len, T); path.lineTo(R, T); path.lineTo(R, T + len)
            path.moveTo(L, B - len); path.lineTo(L, B); path.lineTo(L + len, B)
            path.moveTo(R - len, B); path.lineTo(R, B); path.lineTo(R, B - len)
            c.drawPath(path, br)
            if (showHandle) {
                hp.color = if (dragging) 0xFF377AFF.toInt() else 0xCCB4B4B8.toInt()
                val hw = u(138f)
                val hh = u(12f)
                val cx = region.centerX().toFloat()
                val top = t + u(12f)
                c.drawRoundRect(cx - hw / 2f, top, cx + hw / 2f, top + hh, hh / 2f, hh / 2f, hp)
            }
        }
    }

    private class Chevron(c: Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFFFFFFF.toInt()
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        override fun onDraw(c: Canvas) {
            p.strokeWidth = width / 8f
            val w = width.toFloat()
            val h = height.toFloat()
            c.drawLine(w * 0.12f, h * 0.3f, w * 0.5f, h * 0.7f, p)
            c.drawLine(w * 0.5f, h * 0.7f, w * 0.88f, h * 0.3f, p)
        }
    }

    private fun clampRegion(dx: Int, dy: Int, o: Rect) {
        val w = o.width()
        val h = o.height()
        val l = (o.left + dx).coerceIn(0, max(0, screenW - w))
        val t = (o.top + dy).coerceIn(0, max(0, screenH - h))
        region.set(l, t, l + w, t + h)
    }

    private fun layoutPill() {
        val pl = pill ?: return
        val lp = pillLp ?: return
        pl.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = pl.measuredWidth
        val h = pl.measuredHeight
        lp.x = (region.centerX() - w / 2).coerceIn(svc.ui(20f), max(svc.ui(20f), screenW - w - svc.ui(20f)))
        var y = region.bottom + svc.ui(65f)
        if (y + h > screenH - svc.ui(30f)) y = region.top - svc.ui(65f) - h
        lp.y = y.coerceIn(svc.ui(30f), max(svc.ui(30f), screenH - h - svc.ui(30f)))
        try {
            wm.updateViewLayout(pl, lp)
        } catch (e: Exception) {
        }
    }

    private fun layoutHandle() {
        val hv = handleWin ?: return
        val lp = handleLp ?: return
        lp.x = region.centerX() - lp.width / 2
        lp.y = region.top - svc.ui(10f)
        try {
            wm.updateViewLayout(hv, lp)
        } catch (e: Exception) {
        }
    }

    fun show() {
        val bounds = wm.currentWindowMetrics.bounds
        screenW = bounds.width()
        screenH = bounds.height()

        // 1. visuals (not touchable, so the screen underneath stays usable)
        val ov = Overlay()
        val olp = params(screenW, screenH, false)
        olp.x = 0
        olp.y = 0
        wm.addView(ov, olp)
        overlay = ov
        frameView = ov

        // 2. invisible touch area over the handle: drag it to move the square
        val hv = View(svc)
        val hlp = params(svc.ui(360f), svc.ui(120f), true)
        handleLp = hlp
        var downX = 0f
        var downY = 0f
        val origin = Rect()
        hv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    origin.set(region)
                    ov.dragging = true
                    pill?.alpha = 0f
                    ov.invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    clampRegion((e.rawX - downX).toInt(), (e.rawY - downY).toInt(), origin)
                    ov.invalidate()
                    layoutHandle()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    ov.dragging = false
                    layoutPill()
                    pill?.alpha = 1f
                    ov.invalidate()
                }
            }
            true
        }
        hlp.x = region.centerX() - hlp.width / 2
        hlp.y = region.top - svc.ui(10f)
        wm.addView(hv, hlp)
        handleWin = hv

        // 3. the control row: [dot Record | High quality v]  (X)
        val row = LinearLayout(svc)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val pl = LinearLayout(svc)
        pl.orientation = LinearLayout.HORIZONTAL
        pl.gravity = Gravity.CENTER_VERTICAL
        pl.setPadding(svc.ui(56f), 0, svc.ui(44f), 0)
        pl.background = GradientDrawable().apply {
            setColor(0xF22D2D2F.toInt())
            cornerRadius = u(70f)
        }
        val dot = View(svc)
        dot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xFFFF0000.toInt())
        }
        pl.addView(dot, LinearLayout.LayoutParams(svc.ui(42f), svc.ui(42f)))
        val rec = text("Record", true)
        label = rec
        val rl = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        rl.marginStart = svc.ui(26f)
        pl.addView(rec, rl)
        val div = View(svc)
        div.setBackgroundColor(0x44FFFFFF)
        val dl = LinearLayout.LayoutParams(svc.ui(2f), svc.ui(52f))
        dl.marginStart = svc.ui(32f)
        dl.marginEnd = svc.ui(32f)
        pl.addView(div, dl)
        val q = text("High quality", false)
        quality = q
        pl.addView(q)
        val chev = Chevron(svc)
        val chl = LinearLayout.LayoutParams(svc.ui(40f), svc.ui(26f))
        chl.marginStart = svc.ui(22f)
        pl.addView(chev, chl)
        val closeBtn = CloseButton(svc, 0xF22D2D2F.toInt())
        val cl = LinearLayout.LayoutParams(svc.ui(124f), svc.ui(124f))
        cl.marginStart = svc.ui(43f)
        row.addView(pl, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, svc.ui(126f)))
        row.addView(closeBtn, cl)

        rec.setOnClickListener {
            if (!recording) startRecording() else stopRecording()
        }
        dot.setOnClickListener { rec.performClick() }
        val toggleQuality = View.OnClickListener {
            if (!recording) {
                high = !high
                q.text = if (high) "High quality" else "Standard quality"
                layoutPill()
            }
        }
        q.setOnClickListener(toggleQuality)
        chev.setOnClickListener(toggleQuality)
        closeBtn.setOnClickListener { dismiss() }

        val plp = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, true)
        pillLp = plp
        wm.addView(row, plp)
        pill = row
        layoutPill()
    }

    private fun text(s: String, bold: Boolean): TextView {
        val t = TextView(svc)
        t.text = s
        t.setTextColor(0xFFFFFFFF.toInt())
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, u(54f))
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun startRecording() {
        recording = true
        startMs = SystemClock.uptimeMillis()
        // nothing of the handle or the dimming may end up in the GIF
        overlay?.let {
            it.showScrim = false
            it.showHandle = false
            it.invalidate()
        }
        try {
            handleWin?.let { wm.removeView(it) }
        } catch (e: Exception) {
        }
        handleWin = null
        label?.text = "Stop  0:00"
        quality?.alpha = 0.4f
        scheduleShot()
    }

    private fun scheduleShot() {
        if (!recording) return
        val wait = max(0L, 340L - (SystemClock.uptimeMillis() - lastShot))
        handler.postDelayed({ shoot() }, wait)
    }

    private fun shoot() {
        if (!recording) return
        lastShot = SystemClock.uptimeMillis()
        svc.takeShot { bmp ->
            if (bmp != null) worker.execute { addFrame(bmp) }
            val sec = ((SystemClock.uptimeMillis() - startMs) / 1000).toInt()
            label?.text = "Stop  ${sec / 60}:${(sec % 60).toString().padStart(2, '0')}"
            if (sec >= 20) stopRecording() else scheduleShot()
        }
    }

    private fun addFrame(full: Bitmap) {
        try {
            val l = region.left.coerceIn(0, full.width - 1)
            val t = region.top.coerceIn(0, full.height - 1)
            val w = region.width().coerceIn(1, full.width - l)
            val h = region.height().coerceIn(1, full.height - t)
            val crop = Bitmap.createBitmap(full, l, t, w, h)
            if (fw == 0) {
                val maxDim = if (high) 720f else 480f
                val s = minOf(1f, maxDim / max(w, h))
                fw = max(2, (w * s).toInt() and 1.inv())
                fh = max(2, (h * s).toInt() and 1.inv())
            }
            val scaled = Bitmap.createScaledBitmap(crop, fw, fh, true)
            val px = IntArray(fw * fh)
            scaled.getPixels(px, 0, fw, 0, 0, fw, fh)
            frames.add(GifEncoder.quantize(px, fw, fh))
            if (scaled !== crop) scaled.recycle()
            crop.recycle()
            full.recycle()
        } catch (e: Exception) {
        }
    }

    private fun stopRecording() {
        recording = false
        removeViews()
        Toast.makeText(svc, "Creating GIF\u2026", Toast.LENGTH_SHORT).show()
        worker.execute {
            val ok = if (frames.isEmpty()) {
                false
            } else {
                val bytes = GifEncoder.encode(frames, fw, fh, 33)
                saveToPictures(svc, "AISelect_${System.currentTimeMillis()}.gif", "image/gif", bytes)
            }
            handler.post {
                Toast.makeText(svc, if (ok) "GIF saved to Pictures/AI Select" else "Couldn't create GIF", Toast.LENGTH_LONG).show()
                svc.gifFinished()
            }
            worker.shutdown()
        }
    }

    private fun removeViews() {
        try {
            frameView?.let { wm.removeView(it) }
        } catch (e: Exception) {
        }
        try {
            pill?.let { wm.removeView(it) }
        } catch (e: Exception) {
        }
        try {
            handleWin?.let { wm.removeView(it) }
        } catch (e: Exception) {
        }
        frameView = null
        overlay = null
        handleWin = null
        pill = null
    }

    fun dismiss() {
        recording = false
        removeViews()
        worker.shutdown()
        svc.gifFinished()
    }
}
