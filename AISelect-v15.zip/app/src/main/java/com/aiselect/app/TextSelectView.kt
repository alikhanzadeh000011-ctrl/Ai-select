package com.aiselect.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * Text selection like the original: every recognised word is highlighted, a teardrop handle sits under
 * the first and the last selected word and can be dragged to change the selection.
 */
class TextSelectView(context: Context) : View(context) {

    class Word(val text: String, val box: RectF, val line: Int)

    var words: List<Word> = emptyList()
        set(v) {
            field = v
            start = 0
            end = v.size - 1
            invalidate()
        }
    var start = 0
    var end = -1

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xA67FB2D6.toInt() }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = context.u(32f)
    private val pad = context.u(4f)
    private var drag = 0
    private val path = Path()
    private val rect = RectF()

    fun selectedText(): String {
        if (words.isEmpty() || end < start) return ""
        val sb = StringBuilder()
        var lastLine = -1
        for (i in start..end) {
            val w = words[i]
            if (lastLine != -1) sb.append(if (w.line != lastLine) "\n" else " ")
            sb.append(w.text)
            lastLine = w.line
        }
        return sb.toString()
    }

    private fun handleRect(i: Int, isStart: Boolean): RectF {
        val b = words[i].box
        return if (isStart) RectF(b.left - 2 * r, b.bottom, b.left, b.bottom + 2 * r)
        else RectF(b.right, b.bottom, b.right + 2 * r, b.bottom + 2 * r)
    }

    private fun drawHandle(c: Canvas, i: Int, isStart: Boolean) {
        val h = handleRect(i, isStart)
        handlePaint.shader = LinearGradient(h.left, h.top, h.left, h.bottom, 0xFF7FC4F0.toInt(), 0xFF8FE3BD.toInt(), Shader.TileMode.CLAMP)
        path.reset()
        val radii = if (isStart) floatArrayOf(r, r, 0f, 0f, r, r, r, r) else floatArrayOf(0f, 0f, r, r, r, r, r, r)
        path.addRoundRect(h, radii, Path.Direction.CW)
        c.drawPath(path, handlePaint)
    }

    override fun onDraw(c: Canvas) {
        if (words.isEmpty() || end < start) return
        for (i in start..end) {
            val b = words[i].box
            rect.set(b.left - pad, b.top - pad, b.right + pad, b.bottom + pad)
            c.drawRoundRect(rect, pad * 1.5f, pad * 1.5f, fill)
        }
        drawHandle(c, start, true)
        drawHandle(c, end, false)
    }

    private fun nearest(x: Float, y: Float): Int {
        var best = 0
        var bestD = Float.MAX_VALUE
        for (i in words.indices) {
            val b = words[i].box
            val dx = max(max(b.left - x, 0f), x - b.right)
            val dy = max(max(b.top - y, 0f), y - b.bottom)
            val d = dx * dx + dy * dy
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        return best
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                drag = 0
                if (words.isNotEmpty() && end >= start) {
                    val hs = handleRect(start, true)
                    val he = handleRect(end, false)
                    val m = r * 0.7f
                    if (e.x >= hs.left - m && e.x <= hs.right + m && e.y >= hs.top - m && e.y <= hs.bottom + m) drag = 1
                    else if (e.x >= he.left - m && e.x <= he.right + m && e.y >= he.top - m && e.y <= he.bottom + m) drag = 2
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (drag != 0) {
                    val idx = nearest(e.x, e.y - r * 1.5f)
                    if (drag == 1) start = min(idx, end) else end = max(idx, start)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> drag = 0
        }
        return true
    }
}
