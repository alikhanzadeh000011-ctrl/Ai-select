package com.aiselect.app

import android.content.Context

/** Settings of the side edge handle. Defaults follow the measurements from the original video. */
object EdgePrefs {
    val COLORS = intArrayOf(
        0xFF1BA85A.toInt(), 0xFF7EE1B1.toInt(), 0xFF4D8DFF.toInt(), 0xFFFFFFFF.toInt(), 0xFF9AA0A6.toInt()
    )

    private fun sp(c: Context) = c.getSharedPreferences("edge", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun right(c: Context) = sp(c).getBoolean("right", true)
    fun setRight(c: Context, v: Boolean) = sp(c).edit().putBoolean("right", v).apply()

    /** Vertical center of the handle, percent of the screen height. */
    fun posY(c: Context) = sp(c).getInt("posY", 35)
    fun setPosY(c: Context, v: Int) = sp(c).edit().putInt("posY", v).apply()

    /** Handle length, percent of the screen height. */
    fun heightPct(c: Context) = sp(c).getInt("heightPct", 14)
    fun setHeightPct(c: Context, v: Int) = sp(c).edit().putInt("heightPct", v).apply()

    /** Handle thickness in dp. */
    fun thickness(c: Context) = sp(c).getInt("thickness", 6)
    fun setThickness(c: Context, v: Int) = sp(c).edit().putInt("thickness", v).apply()

    /** Length (percent of screen height) and thickness (dp) of the colored handle that plays on activation. */
    fun activeHeightPct(c: Context) = sp(c).getInt("activeHeightPct", 14)
    fun setActiveHeightPct(c: Context, v: Int) = sp(c).edit().putInt("activeHeightPct", v).apply()

    fun activeThickness(c: Context) = sp(c).getInt("activeThickness", 6)
    fun setActiveThickness(c: Context, v: Int) = sp(c).edit().putInt("activeThickness", v).apply()

    fun vibrate(c: Context) = sp(c).getBoolean("vibrate", true)
    fun setVibrate(c: Context, v: Boolean) = sp(c).edit().putBoolean("vibrate", v).apply()

    fun invisible(c: Context) = sp(c).getBoolean("invisible", false)
    fun setInvisible(c: Context, v: Boolean) = sp(c).edit().putBoolean("invisible", v).apply()

    fun colorIndex(c: Context) = sp(c).getInt("color", 0).coerceIn(0, COLORS.size - 1)
    fun setColorIndex(c: Context, v: Int) = sp(c).edit().putInt("color", v).apply()
}
