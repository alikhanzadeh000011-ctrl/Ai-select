package com.aiselect.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.min

/**
 * The side handle. Hold it for [HOLD_MS]: the bar turns into the AI Select colors (blue to mint),
 * widens a little, then dims and goes away. Timing measured from the original screen recording.
 */
class EdgeHandleView(context: Context, private val right: Boolean) : View(context) {

    companion object {
        const val HOLD_MS = 900L
        const val ANIM_MS = 340L
    }

    var onLongPress: (() -> Unit)? = null
    var barColor: Int = 0xFF1BA85A.toInt()
    var invisibleMode = false

    /** true: only plays the colored animation, never touchable (second window). */
    var animOnly = false

    /** hides the idle bar of the touch handle while the colored one plays. */
    var suppressIdle = false
        set(v) {
            field = v
            invalidate()
        }
    var barWidthPx = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var t = -1f
    private var anim: ValueAnimator? = null
    private var fired = false
    private var downX = 0f
    private var downY = 0f
    private val slop = ViewConfiguration.get(context).scaledTouchSlop * 2f
    private val fire = Runnable {
        fired = true
        onLongPress?.invoke()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        // keep the system back gesture away from the handle
        if (!animOnly) systemGestureExclusionRects = listOf(Rect(0, 0, w, h))
    }

    fun playActivate() {
        anim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = ANIM_MS
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
        anim = a
        a.start()
    }

    fun resetState() {
        removeCallbacks(fire)
        anim?.cancel()
        t = -1f
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        if (animOnly && t < 0f) return
        if (!animOnly && (suppressIdle || invisibleMode)) return
        val h = height.toFloat()
        var widen = 1f
        var mix = 0f
        var dark = 0f
        var a = 1f
        if (t >= 0f) {
            mix = (t / 0.2f).coerceIn(0f, 1f)
            dark = ((t - 0.75f) / 0.2f).coerceIn(0f, 1f)
            widen = 1f + 0.7f * mix - 0.7f * dark
            a = 1f - ((t - 0.95f) / 0.05f).coerceIn(0f, 1f)
        }
        val bw = barWidthPx * widen
        val left = if (right) width - bw else 0f
        rect.set(left, 0f, left + bw, h)
        val rad = min(bw / 2f, context.u(10f))

        paint.shader = null
        paint.color = barColor
        paint.alpha = ((1f - mix) * a * 255).toInt()
        if (!invisibleMode && paint.alpha > 0) c.drawRoundRect(rect, rad, rad, paint)

        val gm = mix * (1f - dark) * a
        if (gm > 0.01f) {
            paint.shader = LinearGradient(
                0f, 0f, 0f, h,
                0xFF7F95D8.toInt(), 0xFF8EE0B8.toInt(), Shader.TileMode.CLAMP
            )
            paint.alpha = (gm * 255).toInt()
            c.drawRoundRect(rect, rad, rad, paint)
            paint.shader = null
        }

        if (dark > 0.01f) {
            paint.color = 0xFF38393B.toInt()
            paint.alpha = (dark * a * 255).toInt()
            c.drawRoundRect(rect, rad, rad, paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (animOnly) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                fired = false
                removeCallbacks(fire)
                postDelayed(fire, HOLD_MS)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!fired && (abs(e.rawX - downX) > slop || abs(e.rawY - downY) > slop)) {
                    removeCallbacks(fire)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> removeCallbacks(fire)
        }
        return true
    }
}
