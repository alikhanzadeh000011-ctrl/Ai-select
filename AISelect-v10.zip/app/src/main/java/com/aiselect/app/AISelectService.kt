package com.aiselect.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.VibratorManager
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast

/**
 * Takes the screenshot (no MediaProjection prompt) and opens [SelectActivity].
 * It only runs when you trigger it; it never reads or stores anything from the screen.
 */
class AISelectService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AISelectService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var busy = false
    private var gif: GifRecorder? = null

    private var edge: EdgeHandleView? = null
    private var edgeFx: EdgeHandleView? = null
    private var edgeCx = -1f
    private var edgeCy = -1f

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        refreshEdge()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        removeEdge()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        removeEdge()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        handler.post { refreshEdge() }
    }

    // ---------- Edge handle ----------

    private fun removeEdge() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        for (v in listOf(edge, edgeFx)) {
            if (v == null) continue
            try {
                wm.removeView(v)
            } catch (e: Exception) {
            }
        }
        edge = null
        edgeFx = null
    }

    /** (Re)builds the side handle from the saved settings. */
    fun refreshEdge() {
        removeEdge()
        if (!EdgePrefs.enabled(this)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = wm.currentWindowMetrics.bounds
        val sh = b.height()
        val dens = resources.displayMetrics.density
        val thick = EdgePrefs.thickness(this) * dens
        val winW = (thick * 2f + 10f * dens).toInt()
        val winH = (sh * EdgePrefs.heightPct(this) / 100f).toInt().coerceAtLeast((40f * dens).toInt())
        val right = EdgePrefs.right(this)

        val v = EdgeHandleView(this, right)
        v.barWidthPx = thick
        v.barColor = EdgePrefs.COLORS[EdgePrefs.colorIndex(this)]
        v.invisibleMode = EdgePrefs.invisible(this)
        v.onLongPress = { onEdgeLongPress() }

        val lp = WindowManager.LayoutParams(
            winW,
            winH,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or (if (right) Gravity.END else Gravity.START)
        lp.y = (sh * EdgePrefs.posY(this) / 100f - winH / 2f).toInt().coerceIn(0, (sh - winH).coerceAtLeast(0))
        edgeCx = if (right) b.width().toFloat() else 0f
        edgeCy = lp.y + winH / 2f
        try {
            wm.addView(v, lp)
            edge = v
        } catch (e: Exception) {
        }

        // second window: the colored handle that plays on activation, sized separately and not touchable
        val aThick = EdgePrefs.activeThickness(this) * dens
        val aW = (aThick * 2f + 6f * dens).toInt()
        val aH = (sh * EdgePrefs.activeHeightPct(this) / 100f).toInt().coerceAtLeast((40f * dens).toInt())
        val fx = EdgeHandleView(this, right)
        fx.animOnly = true
        fx.barWidthPx = aThick
        fx.barColor = EdgePrefs.COLORS[EdgePrefs.colorIndex(this)]
        fx.invisibleMode = EdgePrefs.invisible(this)
        val lp2 = WindowManager.LayoutParams(
            aW,
            aH,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp2.gravity = Gravity.TOP or (if (right) Gravity.END else Gravity.START)
        lp2.y = (edgeCy - aH / 2f).toInt().coerceIn(0, (sh - aH).coerceAtLeast(0))
        try {
            wm.addView(fx, lp2)
            edgeFx = fx
        } catch (e: Exception) {
        }
    }

    /** Hidden while the AI Select screen is open so it never ends up in a screenshot. */
    fun setEdgeShown(shown: Boolean) {
        val v = edge ?: return
        v.resetState()
        v.suppressIdle = false
        v.visibility = if (shown) View.VISIBLE else View.INVISIBLE
        edgeFx?.let {
            it.resetState()
            it.visibility = if (shown) View.VISIBLE else View.INVISIBLE
        }
    }

    private fun buzz() {
        try {
            val vib = getSystemService(VibratorManager::class.java).defaultVibrator
            vib.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_HEAVY_CLICK))
        } catch (e: Exception) {
            try {
                val vib = getSystemService(VibratorManager::class.java).defaultVibrator
                vib.vibrate(VibrationEffect.createOneShot(40L, VibrationEffect.DEFAULT_AMPLITUDE))
            } catch (e2: Exception) {
            }
        }
    }

    /**
     * Timeline measured from the original recording, counted from the moment the hold is recognised:
     * 0 ms vibration + handle turns blue/mint, ~330 ms handle gone, ~390 ms screenshot,
     * 700 ms the AI Select effect starts.
     */
    private fun onEdgeLongPress() {
        if (busy) return
        val v = edge ?: return
        val t0 = SystemClock.uptimeMillis()
        if (EdgePrefs.vibrate(this)) buzz()
        v.suppressIdle = true
        edgeFx?.playActivate()
        handler.postDelayed({
            v.visibility = View.INVISIBLE
            edgeFx?.visibility = View.INVISIBLE
        }, 330)
        val ox = edgeCx
        val oy = edgeCy
        handler.postDelayed({ capture(t0 + 700L, ox, oy) }, 390)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    fun captureDelayed(delayMs: Long) {
        handler.postDelayed({ capture() }, delayMs)
    }

    /** Screenshot as a software bitmap, or null on failure. Callback runs on the main thread. */
    fun takeShot(cb: (Bitmap?) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                var soft: Bitmap? = null
                try {
                    val buffer = result.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                    soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hw?.recycle()
                    buffer.close()
                } catch (e: Exception) {
                    soft = null
                }
                cb(soft)
            }

            override fun onFailure(errorCode: Int) {
                cb(null)
            }
        })
    }

    private fun capture(entryAt: Long = 0L, ox: Float = -1f, oy: Float = -1f) {
        if (busy) return
        busy = true
        takeShot { bmp ->
            busy = false
            if (bmp != null) {
                ShotHolder.bitmap = bmp
                ShotHolder.entryAt = entryAt
                ShotHolder.originX = ox
                ShotHolder.originY = oy
                setEdgeShown(false)
                val i = Intent(this, SelectActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                startActivity(i)
            } else {
                setEdgeShown(true)
                Toast.makeText(this, "Screenshot failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------- Pin ----------

    fun pin(bmp: Bitmap, x: Int, y: Int) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = FrameLayout(this)
        val iv = ImageView(this)
        iv.setImageBitmap(bmp)
        box.addView(iv, FrameLayout.LayoutParams(bmp.width, bmp.height))
        box.background = GradientDrawable().apply {
            setStroke(ui(4f), 0xE6FFFFFF.toInt())
            setColor(0x00000000)
        }
        box.elevation = ui(12f).toFloat()
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = x
        lp.y = y

        val close = CloseButton(this)
        val cs = ui(64f)
        val cl = FrameLayout.LayoutParams(cs, cs, Gravity.TOP or Gravity.END)
        cl.topMargin = ui(10f)
        cl.marginEnd = ui(10f)
        box.addView(close, cl)
        close.setOnClickListener {
            try {
                wm.removeView(box)
            } catch (e: Exception) {
            }
        }

        var dx = 0f
        var dy = 0f
        var sx = 0
        var sy = 0
        box.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX
                    dy = e.rawY
                    sx = lp.x
                    sy = lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - dx).toInt()
                    lp.y = sy + (e.rawY - dy).toInt()
                    try {
                        wm.updateViewLayout(box, lp)
                    } catch (ex: Exception) {
                    }
                }
            }
            true
        }
        wm.addView(box, lp)
    }

    // ---------- GIF ----------

    fun startGif(region: Rect) {
        gif?.dismiss()
        val g = GifRecorder(this, region)
        gif = g
        g.show()
    }

    fun gifFinished() {
        gif = null
    }
}
